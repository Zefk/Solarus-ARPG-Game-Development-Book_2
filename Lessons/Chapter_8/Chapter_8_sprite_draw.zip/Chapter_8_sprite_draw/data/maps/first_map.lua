-- Drawing a sprite
-- Tip: A common usage for sprite drawing is for scenes. 
-- For example, when an boss enemy or hero dies because the drawn sprite can be unpaused when the game is paused.
-- http://www.solarus-games.org/doc/latest/lua_api_sprite.html#lua_api_sprite_set_paused

-- Lua script of map first_map.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest


local map = ...
local game = map:get_game()

local x_pos, y_pos = 100, 100 -- x,y coordinates
local x,y -- drawing coordinates

sol.timer.start(100, function() --Timer for checking. Normally not needed if you pause the game.
  local camera_x, camera_y = map:get_camera():get_bounding_box() -- Minus the camera for correct map position.
  y = y_pos - camera_y -- y_pos = y_pos - camera_y will constantly minus the camera coordinates, use variable "y" when drawing.
  x = x_pos - camera_x
  return true -- repeat timer
end)

local sprite = sol.sprite.create("main_heroes/eldran") -- sprite you want to draw.
sprite:set_animation("dying") -- do not loop it in the sprite editor or it will keep doing the dying animation

function sprite:on_animation_finished() --function for when the dying animation ends.
  sprite:set_animation("dead")
end

function map:on_draw(screen) -- draw sprite
  sprite:draw(screen, x, y)
end

