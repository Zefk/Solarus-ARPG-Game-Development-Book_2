-- The star shown on the game screen.

local star_builder = {}

local star_icon_img = sol.surface.create("hud/star_icon.png")

function star_builder:new(game, config)

  local star = {}

  local dst_x, dst_y = config.x, config.y

  function star:on_draw(dst_surface)
    local x, y = dst_x, dst_y

    star_icon_img:draw(dst_surface, x, y)
  end

  return star
end

return star_builder