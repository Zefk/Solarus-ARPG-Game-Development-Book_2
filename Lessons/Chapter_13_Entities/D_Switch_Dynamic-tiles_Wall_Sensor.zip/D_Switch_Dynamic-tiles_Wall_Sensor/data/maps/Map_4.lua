-- Lua script of map Map_4.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

function map:on_started()

 --chest_1
  if game:get_value("Map_4_gem_treasure") then
    chest_button:set_activated(true)
  else
    chest:set_enabled(false)
  end
  
  --chest_2
  if game:get_value("Map_4_gem_treasure_2") then
    chest_button_2:set_activated(true)
  else
    chest_2:set_enabled(false)
  end

  if chest_2:is_open() then
    chest_button_2:set_activated(true)
    block:set_position(216,308)
  else
    chest_2:set_enabled(false)
  end

--Solid Switch bridge

 if chest_bridge:is_open() then
    bridge:set_enabled(true)
    solid_switch:set_activated(true)
 end
end

 --chest_1
function chest_button:on_activated()
  sol.audio.play_sound("chest_appears")
  chest:set_enabled(true)
end

 --chest_2
function chest_button_2:on_activated()
  sol.audio.play_sound("chest_appears")
  chest_2:set_enabled(true)
end


function chest_button_2:on_inactivated()
  if not  chest_2:is_open() then
    chest_2:set_enabled(false)
  end
end

--Solid Switch bridge

function solid_switch:on_activated()
   bridge:set_enabled(true)
end

--Bridge sensor

function ground_sensor_1:on_activated()
    hero:save_solid_ground()
    bridge_2:set_enabled(true)

    if enemy_wall == nil then

    else
      enemy_wall:remove()
    end
end

--destination sensor

function ground_sensor_2:on_activated()
  hero:save_solid_ground()
  hero:set_position(up_stairs_2:get_position())
end

function ground_sensor_3:on_activated()
  hero:save_solid_ground()

  local tile_index = 1
  sol.timer.start(400, function()
    local previous_tile = map:get_entity("tile_" .. tile_index)
    local next_tile = map:get_entity("tile_" .. (tile_index + 1))
    tile_index = tile_index + 1
    previous_tile:set_enabled(true)
    if next_tile == nil then
      --finished
      return false
    end
    next_tile:set_enabled(true)
    return true
  end)
end

--[[
--Do not name your sensor, "sensor." Do not give it the same name. 


for sensor in map:get_entities("ground_sensor_") do

   function sensor:on_activated()
     hero:save_solid_ground()
   end
end

--]]



