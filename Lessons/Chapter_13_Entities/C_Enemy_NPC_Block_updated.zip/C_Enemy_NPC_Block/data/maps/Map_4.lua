-- Lua script of map Map_4.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

function big_boss:on_interaction()

  if game:get_value("hammer_quest_started")then
    game:start_dialog("hammer.done")
  else
    game:start_dialog("hammer.hello", function(answer)
      if answer == 3 then --No
        game:start_dialog("hammer.no") 
      else
        game:start_dialog("hammer.yes", function()
          hero:start_treasure("gem", 1, "hammer_quest_started",function()
            game:start_dialog("hammer.wonderful_day")
          end)
        end)
      end
    end)
  end
end