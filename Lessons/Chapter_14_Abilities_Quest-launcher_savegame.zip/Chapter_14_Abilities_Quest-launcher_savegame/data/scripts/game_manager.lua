require("scripts/menus/alttp_dialog_box")
require("scripts/multi_events")
require("scripts/hud/hud")

local game_manager = {}

-- Starts the game from the given savegame file,
-- initializing it if necessary.
function game_manager:start_game()

  local exists = sol.game.exists("save1.dat")
  local game = sol.game.load("save1.dat")
  if not exists then
    --Initialize a new savegame

    game:set_max_life(12)
    game:set_life(game:get_max_life())
    game:set_ability("lift", 2)
    game:set_max_money(100)
    game:set_ability("sword", 2)
    game:set_ability("sword_knowledge", 1)
    game:set_ability("shield", 1)
    game:set_ability("swim", 1)
    game:set_ability("jump_over_water", 1)
    game:set_starting_location("forest", "starting_destination") -- Starting location.
  end


 game:register_event("on_started", function()

    local hero = game:get_hero()
    hero:set_tunic_sprite_id("main_heroes/eldran")
 end)
  game:start()

function game:on_paused()
  game:start_dialog("pause.save_question", function(answer)
    if answer == 2 then
      game:save()
    end
    game:set_paused(false)
  end)
 end
end

return game_manager

