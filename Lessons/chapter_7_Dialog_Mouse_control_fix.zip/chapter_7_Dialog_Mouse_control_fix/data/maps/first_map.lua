local map = ...
local game = map:get_game()

local value = 5

game:start_dialog("_dialog.test2", value)

--game:stop_dialog("_dialog.test")