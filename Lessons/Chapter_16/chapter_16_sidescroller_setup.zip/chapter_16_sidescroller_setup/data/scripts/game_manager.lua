--[[

-------------------------
Sidescroller information:
-------------------------
Please check back at the original post because the patch I made might no longer be needed.
http://forum.solarus-games.org/index.php/topic,297.msg7157.html#msg7157

--------
Credits:
--------
Wrightmat's script <http://forum.solarus-games.org/index.php?action=profile;u=10>
Patch by zane Kukta (zefk)

Features:

-Water - dynamic tiles named "water" will make the hero swim, but if not a traverable attribute and is deep water, then the hero will be able to move the block over the water instead of the block falling.
-Bow
-Carrying - the hero can carry destructible objects up ladders and instantly throws them in water.
-Sword
-Run
-Lift
-Swim (Water tiles need to be dynamic and be named water)
-Tapping
-shield - A aniamtion problem when key "c" and key "space" fast. Although, I think that is just a shield graphic problem on my part.
-Block -- Do not have deep water and a block on the same map because the hero can push/pull it over the deep water. A dymanic traverable would work with gravity. Name the block "g"
-Chests - Can be opened when climbing a ladder, but it can't be opened from the back or sides. A custom chest is needed for that.
-Gravity - Wrightmat has a little gravity feature for entities. Name them "g" and they will fall.

--]]


require("scripts/multi_events")
local initial_game = require("scripts/initial_game")

local game_manager = {}
local game_over_menu = {}
local map_metatable = sol.main.get_metatable("map")
 
local gravity = 5       -- How often to update gravity in milliseconds (move the hero down one pixel this often). Default is every 10 ms.
local jump_height = 40  -- How high to make the hero go when he jumps (in pixels). Default is 40.
local multi_jump = 2    -- How many times to allow the character to jump. Default is 1, or enter 0 to disable jumping entirely.
local state             -- "stopped", "walking", "jumping", "ladder", "dying", "action", "attack"
local last_anim
local water = false     -- false by default. Does not change anything if changed. Water tiles need to be named, "water" and be converted to dynamic.
local facing_up = true  -- Prevents the hero from facing up if false except when using a ladder. The hero can turn to shoot projectiles on ladder.

function game_manager:start_game()

  local exists = sol.game.exists("save1.dat")
  local game = sol.game.load("save1.dat")
  if not exists then
    -- Initialize a new savegame.
    game:set_max_life(3)
    game:set_life(game:get_max_life())
    game:set_ability("swim", 1)
    game:set_ability("shield", 1)
    game:set_ability("run", 1)
    game:set_ability("lift", 1)    --Animation "action" is required for lifting items. It is a duplicate of lifting.
    game:set_ability("sword", 1) -- requires animation attack. A duplicate of animation sword.
    game:set_starting_location("first_map")
  end
  game:start()
  
  function game:on_started()

   local hero = game:get_hero()
   hero:set_tunic_sprite_id("main_heroes/eldran")

    sol.timer.start(gravity, function()
      if self:get_map() ~= nil then
        -- Gravity: move entities down one pixel on every update if there's no collision.
        --   (like with the ground or a platform) and hero not jumping or on a ladder.
        local hero = self:get_hero()
        local x, y, l = hero:get_position()

      -- set direction for hero and ladder patch
        if facing_up == true then
          if state == "ladder" then
            hero:set_animation("walking")
            hero:set_direction(1)
            if hero:get_state() == "bow" then
              hero:unfreeze()
            end
          elseif hero:get_direction() == 1 and self:is_command_pressed("up") then
            hero:set_direction(0)
            if hero:get_state() == "bow" then
              hero:unfreeze()
            end
          end
          --Check walking direction when leaving ladder patch
          if hero:get_direction() == 1 and self:is_command_pressed("left") then
             hero:set_direction(0) 
             state = "walking"
          end
          if hero:get_direction() == 1 and self:is_command_pressed("right") then
             hero:set_direction(2) 
             state = "walking"
          end
        end
        --Sometimes the hero gets stuck on the "stopping" animation when leaving the ladder, so these checks fix the problem.
        --up key check patch for leaving ladder
        if self:is_command_pressed("up") then
          hero:set_animation("walking")
        end
        --left key check patch for leaving ladder
        if self:is_command_pressed("left") and not hero:get_state() == "carrying" and not hero:get_state() == "carrying" then
          hero:set_animation("walking")
        end
        --right key check patch for leaving ladder
        if self:is_command_pressed("right") and not hero:get_state() == "carrying" then
          hero:set_animation("walking")
        end
        --prevents carrying animation with sword charging and space key patch
        if self:is_command_pressed("action") and hero:get_state() == "sword loading" then
          hero:set_animation("sword_loading_walking")
        end
        --prevents carrying animation with sword swinging and space key patch
        if self:is_command_pressed("action") and hero:get_state() == "sword swinging" then
          hero:set_animation("sword")
        end
        if self:is_command_pressed("attack") and hero:get_state() == "sword swinging" then
          hero:set_animation("sword")
        end
        --prevents carrying animation with bow and space key patch
        if self:is_command_pressed("action") and hero:get_state() == "bow" then
          hero:set_animation("bow")
        end
        --prevents carrying/other animation when running patch
        if hero:get_state() == "running" then
          hero:set_animation("running")
        end
        --prevents gltiches with spin attack, but magic or star animation does not appear.
        if hero:get_state() == "sword loading" then
          hero:set_animation("sword_loading_walking")
        end
        --prevents glitches with sword tapping patch
        if hero:get_state() == "sword tapping" then
          hero:set_animation("sword_tapping")
        end
        if hero:get_state() == "sword tapping" and self:is_command_pressed("left") then
          hero:unfreeze()
        end
        if hero:get_state() == "sword tapping" and self:is_command_pressed("right") then
          hero:unfreeze()
        end
        --prevents spin attack glitches patch
        if hero:get_state() == "sword spin attack" then
          hero:set_animation("spin_attack")
        end
        if hero:get_state() == "sword spin attack" and self:is_command_pressed("attack") then
          hero:unfreeze()
        end
        if hero:get_state() == "sword spin attack" and self:is_command_pressed("action") then
          hero:unfreeze()
        end
        --prevents carrying/other animation when carryng patch
        if hero:get_state() == "carrying" and not hero:get_animation() == "carrying_walking" then
          hero:set_animation("carrying_stopped")
        elseif hero:get_state() == "carrying" and not hero:get_animation() == "carrying_stopped" then
          hero:set_animation("carrying_walking")
        end
        --Prevents gltiches with block patch
        if hero:get_state() == "pushing" then
          hero:set_animation("pushing")
        end
        if hero:get_state() == "pulling" then
          hero:set_animation("pulling")
        end
        if hero:get_state() == "grabbing" then
          hero:set_animation("grabbing")
        end

        --checks if hero gets stuck on a ladder when using bow patch
        if state == "ladder" then
          hero:set_animation("walking")
          hero:set_direction(1)
          if hero:get_state() == "bow" then
            hero:unfreeze()
          end
        end

     --Water patch
     for water in self:get_map():get_entities_by_type("dynamic_tile") do
      if hero:overlaps(water) then
        water = true
          hero:set_animation("swimming_stopped")
      elseif not hero:overlaps(water) then
        water = false
      end
      if water == true then
        --Down and left key check patch
        if self:is_command_pressed("down") and self:is_command_pressed("left") then
          hero:set_animation("swimming_slow")
        end
        --Down and right key check patch
        if self:is_command_pressed("down") and self:is_command_pressed("right") then
          hero:set_animation("swimming_slow")
        end
        --up and right key check patch
        if self:is_command_pressed("up") and self:is_command_pressed("right") then
          hero:set_animation("swimming_slow")
        end
        --up and left key check patch
        if self:is_command_pressed("up") and self:is_command_pressed("left") then
          hero:set_animation("swimming_slow")
        end
        --up key check patch
        if self:is_command_pressed("up") then
          hero:set_animation("swimming_slow")
          if hero:get_direction() == 0 then -- facing direction when jumping out of water.
            hero:set_direction(3)
          end
        end
        --down key check patch
        if self:is_command_pressed("down") then
          hero:set_animation("swimming_slow")
        end
        --left key check patch
        if self:is_command_pressed("left") then
          hero:set_animation("swimming_slow")
        end
        --right key check patch
        if self:is_command_pressed("right") then
          hero:set_animation("swimming_slow")
        end
        --action/attack key check patch
        if self:is_command_pressed("attack") or self:is_command_pressed("action") then
          hero:set_animation("swimming_stopped")
        end
        --walking check patch
        if hero:get_animation() == "walking" then
          hero:set_animation("swimming_stopped")
        end
        --stopped check patch
        if hero:get_animation() == "stopped" then
          hero:set_animation("swimming_stopped")
        end
        if hero:get_state() == "carrying" then
          hero:start_attack()
        end
      end
    end
        if state ~= "jumping" and self:get_map():get_ground(hero:get_position()) ~= "ladder" then
          if not hero:test_obstacles(0, 1) then hero:set_position(x, (y + 1), l) end
        elseif state == "jumping" then
          for i = 1, jump_height do
          if not hero:test_obstacles(0, -1) then hero:set_position(x, (y - 1), l) end
          end
          sol.timer.start(gravity * jump_height, function()
            if self:is_command_pressed("right") or self:is_command_pressed("left") then
              state = "walking"
            else
              state = "stopped"
            end
            --right patch
            if self:is_command_pressed("right") and self:is_command_pressed("left") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("right") and self:is_command_pressed("up") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            --left patch
            if self:is_command_pressed("left") and self:is_command_pressed("right") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("left") and self:is_command_pressed("up") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            --up patch
            if self:is_command_pressed("up") and self:is_command_pressed("right") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("up") and self:is_command_pressed("left") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("up") and self:is_command_pressed("down") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("left") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("right") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
          end)
          hero:set_animation(state)
        end

        -- stuck on jump animation patch
        function game:on_key_pressed(key)
          local hero = game:get_hero()

          if key == "up" and key == "down" and key == "left" and key == "right" then
            hero:set_animation("walking")
          else
            hero:set_animation("walking")
          end          
          --Starts sword and checks if the hero gets stuck (requires animation attack. A duplicate of animation sword). Also, check lifting or else the object could vanish to to unfreeze().         
          if key == "action" and state == "stopped" or state == "walking" or key == "left" and not hero:get_animation() == "lifting" or key == "right" and not hero:get_animation() == "lifting" then
            hero:unfreeze()         
          else
            hero:set_animation("stopped")
          end
          --starts bow and checks if hero gets stuck on ladder
          if key == "b" then
            hero:start_bow()
          elseif key == "down" and state == "walking" or state == "ladder" and not hero:get_animation() == "lifting" then
            hero:unfreeze()
          end
        end

        --Free hero patch
        function game:on_key_released(key)
          if hero:get_state() == "sword swinging" then
            hero:unfreeze()
          end
        end
        
        --Fake death patch
        local map = game:get_map()
        --map1
        if game:get_value("map1") == true and map:get_id() == "first_map" then
          if game:get_life() == 1 then
            hero:teleport("first_map", "map1", "fade")
            game:set_life(game:get_max_life())
          end
         --map2
         elseif game:get_value("map2") == true and map:get_id() == "map_leave_test" then
          if game:get_life() == 1 then
            hero:teleport("map_leave_test", "map2", "fade")
            game:set_life(game:get_max_life())
          end
        end
  
        --Entities with he game "g" get gravity.
        for entity in self:get_map():get_entities("g_") do
          local gx, gy, gl = entity:get_position()
          if not entity:test_obstacles(0, 1) then
            entity:set_position(gx, (gy + 1), gl)
          end
        end
      end
      return true
    end)
  end
  
  function game:on_command_pressed(command)
    local hero = game:get_map():get_hero()
    local multi_jump_temp = multi_jump
    if command == "up" then
      if not self:is_suspended() and not jumping and multi_jump_temp > 0 then
        if game:get_map():get_ground(hero:get_position()) ~= "ladder" then
          -- Override default behavior and make the hero jump up!
          state = "jumping"
          multi_jump_temp = multi_jump_temp - 1
        else
          state = "ladder"
        end
      else
        state = "stopped"
      end
    elseif command == "action" and not self:is_suspended() then
      state = "action"
    elseif command == "attack" and not self:is_suspended() then
      state = "attack"
    else
      state = "stopped"
    end
    last_anim = hero:get_animation()
    hero:set_animation(state)
  end
  
  function game:on_command_released(command)
    state = last_anim
    if state == nil then state = "stopped" end
    game:get_map():get_hero():set_animation(state)
  end
--[[
  function game:on_game_over_started()
    sol.menu.start(game:get_map(), game_over_menu)
  end
  
  function game_over_menu:on_started()
    local hero = game:get_hero()
    local map = game:get_map()
    local camera_x, camera_y = map:get_camera():get_position()
    local hero_x, hero_y = hero:get_position()
    hero_dead_x = hero_x - camera_x
    hero_dead_y = hero_y - camera_y
 
    hero_dead_sprite = sol.sprite.create("main_heroes/eldran")
    hero_dead_sprite:set_animation("hurt")
    state = "dying"
 
    sol.audio.stop_music()
    hero:set_visible(false)
    hero_dead_sprite:set_animation("dying")
    hero_dead_sprite.on_animation_finished = function()
      sol.timer.start(self, 500, function()
        game:stop_game_over()
        game:start()
      end)
    end
  end
  
  function game_over_menu:on_finished()
    local hero = game:get_hero()
    if hero ~= nil then hero:set_visible(hero_was_visible) end
    music = nil
    hero_dead_sprite = nil
    fade_sprite = nil
    sol.timer.stop_all(self)
  end
  
  function game_over_menu:on_draw(dst_surface)
    hero_dead_sprite:draw(dst_surface, hero_dead_x, hero_dead_y)
  end
  --]]
end
 
return game_manager