--[[

-------------------------
Sidescroller information:
-------------------------
Please check back at the original post because the patch I made might no longer be needed.
http://forum.solarus-games.org/index.php/topic,297.msg7157.html#msg7157

--------
Credits:
--------
Wrightmat's script <http://forum.solarus-games.org/index.php?action=profile;u=10>
Patch by zane Kukta (zefk)

--]]


require("scripts/multi_events")
local initial_game = require("scripts/initial_game")

local game_manager = {}
local game_over_menu = {}
local map_metatable = sol.main.get_metatable("map")
 
local gravity = 5       -- How often to update gravity in milliseconds (move the hero down one pixel this often). Default is every 10 ms.
local jump_height = 40  -- How high to make the hero go when he jumps (in pixels). Default is 40.
local multi_jump = 2    -- How many times to allow the character to jump. Default is 1, or enter 0 to disable jumping entirely.
local state             -- "stopped", "walking", "jumping", "ladder", "dying", "action", "attack"
local last_anim
local water = false     -- false by default. Does not change anything if changed. Water tiles need to be named, "water" and be converted to dynamic.
local facing_up = true  -- Prevents the hero from facing up if false except when using a ladder. The hero can turn to shoot projectiles on ladder.
 
function game_manager:start_game()

  local exists = sol.game.exists("save1.dat")
  local game = sol.game.load("save1.dat")
  if not exists then
    -- Initialize a new savegame.
    game:set_max_life(3)
    game:set_life(game:get_max_life())
   -- game:set_ability("sword", 1)
    game:set_ability("swim", 1)
    game:set_starting_location("first_map")
  end
  game:start()
  
  function game:on_started()

   local hero = game:get_hero()
   hero:set_tunic_sprite_id("main_heroes/eldran")

    sol.timer.start(gravity, function()
      if self:get_map() ~= nil then
        -- Gravity: move entities down one pixel on every update if there's no collision.
        --   (like with the ground or a platform) and hero not jumping or on a ladder.
        local hero = self:get_hero()
        local x, y, l = hero:get_position()

--Water patch
 for water in self:get_map():get_entities_by_type("dynamic_tile") do
    if hero:overlaps(water) then
      water = true
    elseif not hero:overlaps(water) then
      water = false
    end

      if water == false then
        --Down and left key check patch
        if self:is_command_pressed("down") and self:is_command_pressed("left") then
          hero:set_animation("walking")
        end
        --Down and right key check patch
        if self:is_command_pressed("down") and self:is_command_pressed("right") then
          hero:set_animation("walking")
        end
        --up and right key check patch
        if self:is_command_pressed("up") and self:is_command_pressed("right") then
          hero:set_animation("walking")
        end
        --up and left key check patch
        if self:is_command_pressed("up") and self:is_command_pressed("left") then
          hero:set_animation("walking")
        end
        --up key check patch
        if self:is_command_pressed("up") then
          hero:set_animation("walking")
        end
      -- set direction for hero and ladder patch
       if facing_up == true then
        if state == "ladder" then
          hero:set_animation("walking")
          hero:set_direction(1)
        elseif hero:get_direction() == 1 and self:is_command_pressed("up") then
          hero:set_direction(0)
        end
      end
      end
      if water == true then
        --Down and left key check patch
        if self:is_command_pressed("down") and self:is_command_pressed("left") then
          hero:set_animation("swimming_slow")
        end
        --Down and right key check patch
        if self:is_command_pressed("down") and self:is_command_pressed("right") then
          hero:set_animation("swimming_slow")
        end
        --up and right key check patch
        if self:is_command_pressed("up") and self:is_command_pressed("right") then
          hero:set_animation("swimming_slow")
        end
        --up and left key check patch
        if self:is_command_pressed("up") and self:is_command_pressed("left") then
          hero:set_animation("swimming_slow")
        end
        --up key check patch
        if self:is_command_pressed("up") then
          hero:set_animation("swimming_slow")
        end
        --down key check patch
        if self:is_command_pressed("down") then
          hero:set_animation("swimming_slow")
        end
        --left key check patch
        if self:is_command_pressed("left") then
          hero:set_animation("swimming_slow")
        end
        --right key check patch
        if self:is_command_pressed("right") then
          hero:set_animation("swimming_slow")
        end
        --action/attack key check patch
        if self:is_command_pressed("attack") or self:is_command_pressed("action") then
          hero:set_animation("swimming_stopped")
        end
        --walking check patch
        if hero:get_animation() == "walking" then
          hero:set_animation("swimming_stopped")
        end
        --stopped check patch
        if hero:get_animation() == "stopped" then
          hero:set_animation("swimming_stopped")
        end
      end
    end
        if state ~= "jumping" and self:get_map():get_ground(hero:get_position()) ~= "ladder" then
          if not hero:test_obstacles(0, 1) then hero:set_position(x, (y + 1), l) end
        elseif state == "jumping" then
          for i = 1, jump_height do
          if not hero:test_obstacles(0, -1) then hero:set_position(x, (y - 1), l) end
          end
          sol.timer.start(gravity * jump_height, function()
            if self:is_command_pressed("right") or self:is_command_pressed("left") then
              state = "walking"
            else
              state = "stopped"
            end
            --right patch
            if self:is_command_pressed("right") and self:is_command_pressed("left") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("right") and self:is_command_pressed("up") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            --left patch
            if self:is_command_pressed("left") and self:is_command_pressed("right") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("left") and self:is_command_pressed("up") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            --up patch
            if self:is_command_pressed("up") and self:is_command_pressed("right") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("up") and self:is_command_pressed("left") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
            if self:is_command_pressed("up") and self:is_command_pressed("down") then
              hero:set_animation("walking")
              state = "walking"
            else
              state = "stopped"
            end
          end)

          hero:set_animation(state)
        end

        -- stuck on jump animation patch
        function game:on_key_pressed(key)
          local hero = game:get_hero()

          if key == "up" and key == "down" and key == "left" and key == "right"  then
            hero:set_animation("walking")
          else
            hero:set_animation("walking")
          end
        end
        
        for entity in self:get_map():get_entities("g_") do
          local gx, gy, gl = entity:get_position()
          if not entity:test_obstacles(0, 1) then
            entity:set_position(gx, (gy + 1), gl)
          end
        end
      end
      return true
    end)
  end
  
  function game:on_command_pressed(command)
    local hero = game:get_map():get_hero()
    local multi_jump_temp = multi_jump
    if command == "up" then
      if not self:is_suspended() and not jumping and multi_jump_temp > 0 then
        if game:get_map():get_ground(hero:get_position()) ~= "ladder" then
          -- Override default behavior and make the hero jump up!
          state = "jumping"
          multi_jump_temp = multi_jump_temp - 1
        else
          state = "ladder"
        end
      else
        state = "stopped"
      end
    elseif command == "action" and not self:is_suspended() then
      state = "action"
    elseif command == "attack" and not self:is_suspended() then
      state = "attack"
    else
      state = "stopped"
    end
    last_anim = hero:get_animation()
    hero:set_animation(state)
  end
  
  function game:on_command_released(command)
    state = last_anim
    if state == nil then state = "stopped" end
    game:get_map():get_hero():set_animation(state)
  end

  
  function game:on_game_over_started()
    sol.menu.start(game:get_map(), game_over_menu)
  end
  
  function game_over_menu:on_started()
    local hero = game:get_hero()
    local map = game:get_map()
    local camera_x, camera_y = map:get_camera():get_position()
    local hero_x, hero_y = hero:get_position()
    hero_dead_x = hero_x - camera_x
    hero_dead_y = hero_y - camera_y
 
    hero_dead_sprite = sol.sprite.create("main_heroes/eldran")
    hero_dead_sprite:set_animation("hurt")
    state = "dying"
 
    sol.audio.stop_music()
    hero:set_visible(false)
    hero_dead_sprite:set_animation("dying")
    hero_dead_sprite.on_animation_finished = function()
      sol.timer.start(self, 500, function()
        game:stop_game_over()
        game:start()
      end)
    end
  end
  
  function game_over_menu:on_finished()
    local hero = game:get_hero()
    if hero ~= nil then hero:set_visible(hero_was_visible) end
    music = nil
    hero_dead_sprite = nil
    fade_sprite = nil
    sol.timer.stop_all(self)
  end
  
  function game_over_menu:on_draw(dst_surface)
    hero_dead_sprite:draw(dst_surface, hero_dead_x, hero_dead_y)
  end
end
 
 
return game_manager