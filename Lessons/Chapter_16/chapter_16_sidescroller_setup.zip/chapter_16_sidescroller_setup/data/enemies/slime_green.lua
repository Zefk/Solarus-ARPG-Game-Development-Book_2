--[[
--------
Credits:
--------
Wrightmat's sidescroller monster script <http://forum.solarus-games.org/index.php/topic,297.msg7157.html#msg7157>

Please note: Slime may not have all the animations needed for this script or they are not designed for it.

Patch by Zane Kukta (zefk) for enemy gravity. Little modification of Wrightmat's hero gravity code.
--]]

local enemy = ...
 
local state = "stopped"  -- "stopped", "moving", "going_back" or "paused".
local initial_xy = {}
local activation_distance = 24
 
function enemy:on_created()
  self:set_life(1)
  self:set_damage(2)
  self:create_sprite("enemies/slime_green")
  self:set_size(32, 32)
  self:set_origin(16, 29)
  initial_xy.x, initial_xy.y = self:get_position()
end
 
function enemy:on_update()
  local hero = self:get_map():get_entity("hero")
  if state == "stopped" and self:get_distance(hero) <= 192 then
    -- Check whether the hero is close.
    local x, y = self:get_position()
    local hero_x, hero_y = hero:get_position()
    local dx, dy = hero_x - x, hero_y - y
 
    if math.abs(dy) < activation_distance then
      if dx > 0 then
        self:go(0)
      else
        self:go(2)
      end
    end
    if state == "stopped" and math.abs(dx) < activation_distance then
      if dy > 0 then
        self:go(3)
      else
        self:go(1)
      end
    end
  end
end
 
function enemy:go(direction4)
  local dxy = {
    { x =  8, y =  0},
    { x =  0, y = -8},
    { x = -8, y =  0},
    { x =  0, y =  8}
  }
 
  -- Check that we can make the move.
  local index = direction4 + 1
  if not self:test_obstacles(dxy[index].x * 2, dxy[index].y * 2) then
    state = "moving"
    self:get_sprite():set_animation("walking")
    local x, y = self:get_position()
    local angle = direction4 * math.pi / 2
    local m = sol.movement.create("straight")
    m:set_speed(40)
    m:set_angle(angle)
    m:set_max_distance(104)
    m:set_smooth(false)
    m:start(self)
  end
end
 
function enemy:on_obstacle_reached()
  self:go_back()
end
 
function enemy:on_movement_finished()
  self:go_back()
end
 
function enemy:on_collision_enemy(other_enemy, other_sprite, my_sprite)
  if other_enemy:get_breed() == self:get_breed() and state == "moving" then
    self:go_back()
  end
end
 
function enemy:on_attacking_hero(hero, enemy_sprite)
  -- If hero is above the enemy (jumping on its head), kill it; otherwise, hurt the hero
  if self:get_angle(hero) >= 0.8 and self:get_angle(hero) <= 2.2 then
    self:remove_life(2)
  else
    hero:start_hurt(self, 1)
  end
end
 
function enemy:go_back()
  if state == "moving" then
    state = "going_back"
    self:get_sprite():set_animation("walking")
    local m = sol.movement.create("target")
    m:set_speed(32)
    m:set_target(initial_xy.x, initial_xy.y)
    m:set_smooth(false)
    m:start(self)
  elseif state == "going_back" then
    state = "paused"
    self:get_sprite():set_animation("prepare_jump")
    sol.timer.start(self, 500, function() self:unpause() end)
  end
end
 
function enemy:unpause()
  self:get_sprite():set_animation("prepare_jump")
  state = "stopped"
end


---Gravity patch
local gravity = 5 
local jump_height = 40

    sol.timer.start(gravity, function()
      if enemy:get_map() ~= nil then
        -- Gravity: move entities down one pixel on every update if there's no collision.
        --   (like with the ground or a platform) and hero not jumping or on a ladder.
   
        local x, y, l = enemy:get_position()

        if state ~= "jumping" and enemy:get_map():get_ground(enemy:get_position()) ~= "ladder" then
          if not enemy:test_obstacles(0, 1) then 
            enemy:set_position(x, (y + 1), l) 
            enemy:go_back()
          end
        elseif state == "jumping" then
          for i = 1, jump_height do
            if not enemy:test_obstacles(0, -1) then 
              enemy:set_position(x, (y - 1), l) 
              enemy:go_back()
            end
          end
        end
       end

       return true
     end)