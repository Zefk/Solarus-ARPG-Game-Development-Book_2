require("scripts/menus/alttp_dialog_box")
require("scripts/multi_events")
require("scripts/hud/hud")
local save_load_menu = sol.main.load_file("scripts/save_menu.lua")(game)
local game_over_menu = require("scripts/game_over.lua")

local game_manager = {}



-- Starts the game from the given savegame file,
-- initializing it if necessary.
function game_manager:manage(game)

game:register_event("on_started", function()

  local hero = game:get_hero()

  hero:register_event("on_state_changed", function(hero, state)
    if state == "sword loading" then
      if not game:get_value("skill_spin_attack") then
        game:simulate_command_released("attack")
      end
    end
  end) -- end of hero:register



    --Change hero sprite ID
   hero:set_tunic_sprite_id("main_heroes/eldrina/eldrina")

  --Game over
  print("life"..game:get_life())
  
    function game:on_game_over_started()
        local life = game:get_life()
        if life == 0 then
          hero:set_animation("dead")
          sol.audio.play_sound("hero_dying")
          sol.menu.start(self, game_over_menu)
        end
    end
  end) -- end of game:register_event

  --This happens when the game is paused with the default pause key "D"
  --Save the game
  function game:on_paused()
  	game:start_dialog("pause.save_question", function(answer)
  			if answer == 2 then
  				game:save()
  			end
  				game:set_paused(false)
  	end)
  end

--Load save menu
  function sol.main:on_key_pressed(key)

    if key == "l" then
        sol.menu.start(self, save_load_menu)
        game:set_suspended(true)
    end
  end
end  -- end of game_manager


return game_manager

