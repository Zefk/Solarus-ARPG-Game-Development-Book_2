
local game_over_menu = {}

--Function to go under game:start() in save_menu.lua
function game_over_menu:start(game)

local gameover = {

  browse = 0,

  yes_hover_img = sol.surface.create("game_over/yes_hover.png"),
  no_hover_img = sol.surface.create("game_over/no_hover.png"),
  idle_bg_img = sol.surface.create("game_over/idle_bg.png"),

  yes_hover = true,
  no_hover = false,
	idle_bg = true,

  up = true,
  down = true,
  
  up_sound = "none",
  down_sound = "none",

}

--Set up and down sound
gameover.up_sound = "cursor"
gameover.down_sound ="cursor"



--The draw function for showing images
function game_over_menu:on_draw(screen)

--Show idle-bg-hover image when conditions are true
   if gameover.idle_bg == true then
     gameover.idle_bg_img:draw(screen)
   end

--Show yes-hover image when conditions are true
   if gameover.yes_hover == true then
     gameover.yes_hover_img:draw(screen)
   end

--Show no-hover image when conditions are true
   if gameover.no_hover == true then
     gameover.no_hover_img:draw(screen)
   end

end -- end draw function

--key function for pressing buttons
function game_over_menu:on_key_pressed(key)

--Go down
  if key == "down" and gameover.up == true then
    sol.audio.play_sound(gameover.up_sound)
    if gameover.browse < 1 then
      gameover.browse = gameover.browse + 1
    end
  end

--Go up
  if key == "up" and gameover.down == true then
    sol.audio.play_sound(gameover.down_sound)
    if gameover.browse > 0 then
      gameover.browse = gameover.browse - 1
    end
  end

--Yes hover
  if gameover.browse == 0 then
    print("up")
    gameover.yes_hover = true
    gameover.no_hover = false

local map = game:get_map()

    if key == "a" then

		  game:set_starting_location(map:get_id()) -- Starting location.
		  game:start()
		  game:stop_game_over()
		  sol.menu.stop(self, game_over_menu)
    end
  end

--No hover
  if gameover.browse == 1 then
    print("down")
    gameover.no_hover = true
    gameover.yes_hover = false

    if key == "a" then
		  sol.main.reset()
    end
  end
 end -- end key pressed function
end -- end of function game_over_menu:start(game)


return game_over_menu --return menu
