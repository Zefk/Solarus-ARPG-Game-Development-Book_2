--[[
----------------------------
SCROLLING CREDITS SCRIPT BY: 
----------------------------
===================
Zane Kukta (Zefk)
===================

----------------------------
Solarus ARPG Engine Creator:
----------------------------
============================
Christopho
============================

-------------
About Script:
-------------
===============================================
Scrolling Credits
===============================================

---------
Features:
---------
===================================================================================================================================
+Change spacing of text in, "CHANGE SETTINGS AREA:."
+Change scroll Speed of text in, "CHANGE SETTINGS AREA:."
+Unlimited lists of text in, "CHANGE SETTINGS AREA:."
+Adjust the x-pos of text in, "CHANGE SETTINGS AREA:."
+Change the y-pos starting point of text in, "CHANGE SETTINGS AREA:."
+Change the font of any line of text in, "CHANGE SETTINGS AREA:."
+Change color of any line of text in, "CHANGE SETTINGS AREA:." Uses RGB color, so check the reference list at the end of the script.
+Change the size of any line of text in, "CHANGE SETTINGS AREA:."
+Change the distance of the credits stopping point in, "CHANGE SETTINGS AREA:."
+Change finishing sound in, "CHANGE SETTINGS AREA:."
+Change option for resetting the game in, "CHANGE SETTINGS AREA:."
+Change direction of the scrolling credits in, "CHANGE SETTINGS AREA:."
+Change whether the game pauses during the start of credits in, "CHANGE SETTINGS AREA:."
+Change skip speed and the key's letter in, "CHANGE SETTINGS AREA:."
==================================================================================================================================

-------------
Instructions:
-------------
===========================================================================
sol.main.load_file("scripts/scrolling_credits.lua")(game) or use require.
===========================================================================

-----------------------
Script Completion Date:
-----------------------
==============================
7-16-18 [July 18th, 2018]
==============================

--------
License: 
--------
=============================================================================================================================================
Free under GPLv3 by default. It uses Solarus functions and Solarus is under GPLv3. Credit the (2) people involved in script and link to their websites.

---------
Websites:
---------
Zane Kukta (Zefk) <http://zelzec-entertainment.weebly.com/>
Christopho <http://www.solarus-games.org/>
=============================================================================================================================================
--]]

--Tell the script to use game functions
local game = ...

local name_list ={
      name = {},
      color_type={},
      font_size={},
      font={},
      font_x = {},
      font_y = {},
      font_y_axis,
      line_text = {},
      spacing,
      scroll_speed = 0,
}

-----------------------
--CHANGE SETTINGS AREA:
-----------------------

--The amount of text lines to display
local list_text_amount = 76

--The space between each character and box.
name_list.spacing = 14

--Scrolling speed
name_list.scroll_speed = 40

--Set max distance
local set_max_distance = 1150

--Sound played when credits are done
local finish_sound = "chest_appears"

--Reset game when credits are done
local reset = true

--Direction of credits. Up is false.
local down = false

--Pause game when credits start
local pause = true

--Skip key and speed
local skip_key = "s"

local skip_speed = 1000

--Adjust how far down the name list goes.
name_list.font_y_axis = 100

--Change characters to show
name_list.line_text[0] = "Audio"
name_list.line_text[1] = "------"
name_list.line_text[2] = "Diarandor"
name_list.line_text[3] = "Eduardo Dueñas"
name_list.line_text[4] = "Zane Kukta (zefk)"
name_list.line_text[5] = "\"Closing In On the Loot_Looping\""
name_list.line_text[6] = "\"Hypnotic Orient_Looping\""
name_list.line_text[7] = "\"Magical Getaway_Looping\""
name_list.line_text[8] = "\"Pride_v002\""
name_list.line_text[9] = "\"The 8 Bit Digger\""
name_list.line_text[10] = "\"Young Heroes\""
name_list.line_text[11] = "by Eric Matyas"
name_list.line_text[12] = "www.soundimage.org"
name_list.line_text[13] = ""
name_list.line_text[14] = "Graphics"
name_list.line_text[15] = "----------"
name_list.line_text[16] = "Diarandor"
name_list.line_text[17] = "Christopho"
name_list.line_text[18] = "Neovyse"
name_list.line_text[19] = "Vlag"
name_list.line_text[20] = "Andrew Tyler"
name_list.line_text[21] = "Bertram"
name_list.line_text[22] = "Zane Kukta (zefk)"
name_list.line_text[23] = "Olivier Cléro"
name_list.line_text[24] = "Yusuke Kamiyamane"
name_list.line_text[25] = "gwes"
name_list.line_text[26] = "Reemax (Tuomo Untinen)"
name_list.line_text[27] = "Artisticdude"
name_list.line_text[28] = "interdimensional_"
name_list.line_text[29] = "http://interdimensional.space/"
name_list.line_text[30] = "titi_son"
name_list.line_text[31] = "Maxs"
name_list.line_text[32] = "Blarumyrran"
name_list.line_text[33] = "Daniel Cook (Lostgarden.com)"
name_list.line_text[34] = "Benjamin Pickhardt (hackcraft.de)"
name_list.line_text[35] = "Hyptosis"
name_list.line_text[36] = "Zabin"
name_list.line_text[37] = "arikel"
name_list.line_text[38] = "Viktor Hahn (Viktor.Hahn@web.de)"
name_list.line_text[39] = "AlexCons"
name_list.line_text[40] = "Calciumtrice"
name_list.line_text[41] = "Stephen Challener (Redshrike)"
name_list.line_text[42] = "http://opengameart.org"
name_list.line_text[43] = "Casper Nilsson"
name_list.line_text[44] = "Daniel Eddeland"
name_list.line_text[45] = "Johann CHARLOT"
name_list.line_text[46] = "Skyler Robert Colladay"
name_list.line_text[47] = "Lanea Zimmerman (AKA Sharm)"
name_list.line_text[48] = "Stephen Challener (AKA Redshrike)"
name_list.line_text[49] = "Charles Sanchez (AKA CharlesGabriel)"
name_list.line_text[50] = "Manuel Riecke (AKA MrBeast)"
name_list.line_text[51] = "Daniel Armstrong (AKA HughSpectrum)"
name_list.line_text[52] = ""
name_list.line_text[53] = "Programming"
name_list.line_text[54] = "--------------"
name_list.line_text[55] = "Zane Kukta (zefk)"
name_list.line_text[56] = "Diarandor"
name_list.line_text[57] = "Christopho"
name_list.line_text[58] = ""
name_list.line_text[59] = "Solarus Engine"
name_list.line_text[60] = "-----------------"
name_list.line_text[61] = "Christopho & Solarus Team"
name_list.line_text[62] = "Neovyse"
name_list.line_text[63] = "Diarandor"
name_list.line_text[64] = "Maxs"
name_list.line_text[65] = "Newlink"
name_list.line_text[66] = "Renku"
name_list.line_text[67] = "std::gregwar"
name_list.line_text[68] = "Binbin"
name_list.line_text[69] = ""
name_list.line_text[70] = "Special Thanks"
name_list.line_text[71] = "-----------------"
name_list.line_text[72] = "wrightmat"
name_list.line_text[73] = "MetalZelda"
name_list.line_text[74] = "llamazing"
name_list.line_text[75] = "Max"
name_list.line_text[76] = "Claire Moore (nate-devv)"


--Adjust the x-axis of font pack display for the seven names.
for rep = 0,76 do
  name_list.font_x[rep] = 120
end

--Change the font package
--name_list.font[?] = nil

for rep = 0,76 do
  name_list.font[rep] = "minecraftia"
end

--Change font size
name_list.font_size[0] = 10

for rep = 1,13 do
  name_list.font_size[rep] = 6
end

name_list.font_size[14] = 10

for rep = 15,52 do
  name_list.font_size[rep] = 6
end

name_list.font_size[53] = 10

for rep = 54,58 do
  name_list.font_size[rep] = 6
end

name_list.font_size[59] = 10

for rep = 60,69 do
  name_list.font_size[rep] = 6
end

name_list.font_size[70] = 10

for rep = 71,76 do
  name_list.font_size[rep] = 6
end

--Change color. It was set to snow white (Not white 255,255,255, but snow white 255,250,250. Yeah, they are different.)
--Check end of script for some RGB color values.
for rep = 0,76 do
  name_list.color_type[rep] = {255,255,255}
end

-----------------------------
--END OF CHANGE SETTINGS AREA
-----------------------------

--Text properties and name string loading
for rep = 0,list_text_amount do
     name_list.name[rep] = sol.text_surface.create({
      font = name_list.font[rep],
      text = name_list.line_text[rep],
      font_size = name_list.font_size[rep],
      color = name_list.color_type[rep],
    })
end

--The draw function for showing images
function sol.main:on_draw(screen)

--show names when conditions are true
    for rep = 0,list_text_amount do
       name_list.name[rep]:draw(screen,name_list.font_x[rep],name_list.font_y[rep])
    end
end --end of draw function

--key function for pressing buttons
function credits()

--Skip speed and key
function sol.main:on_key_pressed(key)
  if key == skip_key then
    name_list.scroll_speed = skip_speed
    credits()
  end
end

--Font calculations
  for y = 0,list_text_amount do
    name_list.font_y[y] = y * name_list.spacing + name_list.font_y_axis
  end

--Moving credits and max distance
for rep = 0,list_text_amount do
  local movement = sol.movement.create("straight")
  movement:set_speed(name_list.scroll_speed)
  if down == true then
    movement:set_angle(3 * math.pi / 2)
  else
    movement:set_angle(math.pi / 2)
  end
  movement:set_max_distance(set_max_distance)
  movement:start(name_list.name[rep])

--Play sound and reset
  function movement:on_finished()
    sol.audio.play_sound(finish_sound)
    if reset == true then
      sol.main.reset()
    end
  end
end

--Pause game and unpause game
   if pause == true then
      game:set_suspended(true)
   else 
      game:set_suspended(false)
   end
end


--Start credits function
sol.timer.start(1000, credits())

--[[
Source: http://www.rapidtables.com/web/color/RGB_Color.htm

-------------------
RGB REFERENCE LIST:
-------------------
	maroon(128,0,0)

 	dark red(139,0,0)

 	brown(165,42,42)

 	firebrick(178,34,34)

 	crimson	(220,20,60)

 	red(255,0,0)

 	tomato(255,99,71)

 	coral(255,127,80)

 	indian red(205,92,92)

 	light coral(240,128,128)

 	dark salmon(233,150,122)

 	salmon(250,128,114)

 	light salmon(255,160,122)

 	orange red(255,69,0)

 	dark orange(255,140,0)

 	orange(255,165,0)

 	gold(255,215,0)

 	dark golden rod(184,134,11)

 	golden rod(218,165,32)

 	pale golden rod(238,232,170)

 	dark khaki(189,183,107)

 	khaki(240,230,140)

 	olive(128,128,0)

 	yellow(255,255,0)

 	yellow green(154,205,50)

 	dark olive green(85,107,47)

 	olive drab(107,142,35)

 	lawn green(124,252,0)

 	chart reuse(127,255,0)

 	green yellow(173,255,47)

 	dark green(0,100,0)

 	green(0,128,0)

 	forest green(34,139,34)

 	lime(0,255,0)

 	lime green(50,205,50)

 	light green(144,238,144)

 	pale green(152,251,152)

 	dark sea green(143,188,143)

 	medium spring green(0,250,154)

 	spring green(0,255,127)

 	sea green(46,139,87)

 	medium aqua marine(102,205,170)

 	medium sea green(60,179,113)

 	light sea green	(32,178,170)

 	dark slate gray(47,79,79)

 	teal0,128,128)

 	dark cyan(0,139,139)

 	aqua(0,255,255)

 	cyan(0,255,255)

 	light cyan(224,255,255)

 	dark turquoise(0,206,209)

 	turquoise(64,224,208)

 	medium turquoise(72,209,204)

 	pale turquoise(175,238,238)

 	aqua marine(127,255,212)

 	powder blue(176,224,230)

 	cadet blue(95,158,160)

 	steel blue(70,130,180)

 	corn flower blue(100,149,237)

 	deep sky blue(0,191,255)

 	dodger blue(30,144,255)

 	light blue(173,216,230)

 	sky blue(135,206,235)

 	light sky blue(135,206,250)

 	midnight blue(25,25,112)

 	navy(0,0,128)

 	dark blue(0,0,139)

 	medium blue(0,0,205)

 	blue(0,0,255)

 	royal blue(65,105,225)

 	blue violet(138,43,226)

 	indigo(75,0,130)

 	dark slate blue(72,61,139)

 	slate blue(106,90,205)

 	medium slate blue(123,104,238)

 	medium purple(147,112,219)

 	dark magenta(139,0,139)

 	dark violet(148,0,211)

 	dark orchid(153,50,204)

 	medium orchid(186,85,211)

 	purple(128,0,128)

 	thistle(216,191,216)

 	plum(221,160,221)

 	violet(238,130,238)

 	magenta / fuchsia(255,0,255)

 	orchid(218,112,214)

 	medium violet red(199,21,133)

 	pale violet red(219,112,147)

 	deep pink(255,20,147)

 	hot pink(255,105,180)

 	light pink(255,182,193)

 	pink(255,192,203)

 	antique white(250,235,215)

 	beige(245,245,220)

 	bisque(255,228,196)

 	blanched almond(255,235,205)

 	wheat(245,222,179)

 	corn silk(255,248,220)

 	lemon chiffon(255,250,205)

 	light golden rod yellow(250,250,210)

 	light yellow(255,255,224)

 	saddbe brown(139,69,19)

 	sienna(160,82,45)

 	chocolate(210,105,30)

 	peru(205,133,63)

 	sandy brown(244,164,96)

 	burly wood(222,184,135)

 	tan(210,180,140)

 	rosy brown(188,143,143)

 	moccasin(255,228,181)

 	navajo white(255,222,173)

 	peach puff(255,218,185)

 	misty rose(255,228,225)

 	lavender blush(255,240,245)

 	linen (250,240,230)

 	old lace(253,245,230)

 	papaya whip(255,239,213)

 	sea shell(255,245,238)

 	mint cream(245,255,250)

 	slate gray(112,128,144)

 	light slate gray(119,136,153)

 	light steel blue(176,196,222)

 	lavender(230,230,250)

 	floral white(255,250,240)

 	alice blue(240,248,255)

 	ghost white(248,248,255)

 	honeydew(240,255,240)

 	ivory(255,255,240)

 	azure(240,255,255)

 	snow(255,250,250)

 	black(0,0,0)

 	dim gray / dim grey(105,105,105)

 	gray / grey(128,128,128)

 	dark gray / dark grey	(169,169,169)

 	silver(192,192,192)

 	light gray / light grey(211,211,211)

 	gainsboro(220,220,220)

 	white smoke(245,245,245)

 	white(255,255,255)

--------------------------
END OF RGB REFERENCE LIST:
--------------------------
--]]
