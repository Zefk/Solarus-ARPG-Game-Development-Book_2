-- Lua script of custom entity test.
-- This script is executed every time a custom entity with this model is created.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation for the full specification
-- of types, events and methods:
-- http://www.solarus-games.org/doc/latest

local entity = ...
local map = entity:get_map()
local game = entity:get_game()
local hero = map:get_hero()

function entity:on_created()
 self:set_traversable_by(false)
 entity:get_sprite():set_animation("closed")
end

local trick_chest = map:get_entity("trick_chest")

function entity:on_interaction()
 hero:start_hurt(trick_chest, 6)
end

