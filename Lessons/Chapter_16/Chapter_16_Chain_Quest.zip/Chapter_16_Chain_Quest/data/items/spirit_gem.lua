-- Lua script of item spirit_gem.
-- This script is executed only once for the whole game.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation for the full specification
-- of types, events and methods:
-- http://www.solarus-games.org/doc/latest

local item = ...
local map = item:get_map()
local game = item:get_game()

function item:on_created()
  self:set_savegame_variable("sola_house_spirit_gem")
end

function item:on_obtained()
  game:set_value("skill_spin_attack",true)
end

function item:on_map_changed(map)
  if game:get_value("sola_house_spirit_gem") then
    local hero = map:get_hero()
    hero:set_walking_speed(130)
  end
end
