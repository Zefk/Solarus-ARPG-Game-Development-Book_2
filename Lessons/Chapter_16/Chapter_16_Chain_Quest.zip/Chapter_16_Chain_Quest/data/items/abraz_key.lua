-- Lua script of item abraz_key.
-- This script is executed only once for the whole game.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation for the full specification
-- of types, events and methods:
-- http://www.solarus-games.org/doc/latest

local item = ...

local game = item:get_game()
local map = item:get_map()

function item:on_created()
  self:set_savegame_variable("abraz_key")
end

function item:on_obtaining()
  game:set_ability("run", 1)
end

--[[
function item:on_map_changed(map)

if game:get_value("abraz_key_obtained") == true then
  local hero = map:get_hero()
  hero:set_walking_speed(300)
end
end
--]]