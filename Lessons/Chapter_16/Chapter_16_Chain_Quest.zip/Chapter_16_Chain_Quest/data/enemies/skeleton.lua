-- Lua script of enemy skeleton.
-- This script is executed every time an enemy with this model is created.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation for the full specification
-- of types, events and methods:
-- http://www.solarus-games.org/doc/latest

local enemy = ...
local game = enemy:get_game()
local map = enemy:get_map()
local hero = map:get_hero()
local sprite
local movement

-- Event called when the enemy is initialized.
function enemy:on_created()

  -- Initialize the properties of your enemy here,
  -- like the sprite, the life and the damage.
  sprite = enemy:create_sprite("enemies/" .. enemy:get_breed())
  enemy:set_life(10)
  enemy:set_damage(2)
end

if game:get_value("boss_map") == true then 
   local solid_1 = map:get_entity("solid_1")
   local solid_2 = map:get_entity("solid_2")
   local solid_3 = map:get_entity("solid_3")
   local solid_4 = map:get_entity("solid_4")

   sol.timer.start(1000, function()
         if solid_1:is_activated() == true and solid_2:is_activated() == true and solid_3:is_activated() == true and solid_4:is_activated() == true then
           enemy:set_attack_consequence("sword", 1)
         else
           enemy:set_attack_consequence("sword", "ignored")
           enemy:set_attack_consequence("explosion", "ignored")
         end
     return true  -- To call the timer again (with the same delay).
   end)
end


-- Event called when the enemy should start or restart its movements.
-- This is called for example after the enemy is created or after
-- it was hurt or immobilized.

local time = 0
--Create on_activated
sol.timer.start(500, function()
  if enemy.on_activated ~= nil then
    enemy:on_activated()
 return true 
  end
end)

function enemy:on_activated()


local distance_to_hero = hero:get_distance(enemy)

   if distance_to_hero < 100 then
   
   time = time + 1
   print("Enemy has been near hero for a total of "..time.." seconds.")
   
     movement = sol.movement.create("target")
     movement:set_target(hero)
     movement:set_speed(48)
     movement:start(enemy)
   else
     movement = sol.movement.create("random")
     movement:start(enemy)
   end
   
end


function enemy:on_movement_changed()

  sprite:set_direction(movement:get_direction4())
end

function enemy:on_dead()
  if game:get_value("scrolling_credits") == true then
    sol.main.load_file("scripts/scrolling_credits.lua")(game)
  end
  game:set_value("sola_house_skeleton", "dead")
  game:set_value("sola_house_switch_off", false)
end