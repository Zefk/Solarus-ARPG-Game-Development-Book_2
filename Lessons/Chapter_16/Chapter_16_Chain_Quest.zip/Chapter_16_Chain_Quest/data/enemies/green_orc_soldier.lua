local enemy = ...

local game = enemy:get_game()
local map = enemy:get_map()
local hero = map:get_hero()
local body_sprite
local sword_sprite
local movement
local immobilize = false
local tapped = 0

function enemy:on_created()

  body_sprite = enemy:create_sprite("enemies/green_orc_soldier")
  sword_sprite = enemy:create_sprite("enemies/green_orc_soldier_sword")
  enemy:set_life(140)
  enemy:set_damage(0)
  enemy:set_size(16, 16)
  enemy:set_origin(8, 13)

  -- Make the sword and body sprite ignore all attacks.
  enemy:set_invincible_sprite(sword_sprite)
  enemy:set_invincible_sprite(body_sprite)

  -- Except the sword.
  enemy:set_attack_consequence_sprite(sword_sprite, "sword", "custom")
end

function enemy:on_custom_attack_received(attack, sprite)

  if attack == "sword" and sprite == sword_sprite then
    sol.audio.play_sound("sword_tapping")
    print("tapped")

    local hero = enemy:get_map():get_entity("hero")
    local angle = hero:get_angle(enemy)
    local movement = sol.movement.create("straight")
    movement:set_speed(128)
    movement:set_angle(angle)
    movement:set_max_distance(500)
    movement:set_smooth(true)
    movement:start(enemy)
    immobilize = true
    tapped = tapped + 1
    print("tapped: ", tapped)
  end
end

--Create on_activated
sol.timer.start(2000, function()
  if enemy.on_activated ~= nil then
    enemy:on_activated()
  return true
  end
end)

function enemy:on_activated()

print("activate")

if immobilize == true then
  enemy:immobilize()
end

if tapped >= 3 then
  game:set_value("underground_tapped_3_times",true)
end

local distance_to_hero = hero:get_distance(enemy)

   if distance_to_hero < 100 then   
     movement = sol.movement.create("target")
     movement:set_target(hero)
     movement:set_speed(48)
     movement:start(enemy)
     immobilize = false
   else
     movement = sol.movement.create("random")
     movement:start(enemy)
     immobilize = false
   end
end

function enemy:on_movement_changed()

  body_sprite:set_direction(movement:get_direction4())
  sword_sprite:set_direction(movement:get_direction4())
end

