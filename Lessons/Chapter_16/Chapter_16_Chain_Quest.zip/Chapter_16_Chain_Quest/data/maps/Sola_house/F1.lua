-- Lua script of map Sola_house/F1.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()
local hero = map:get_hero()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()
--Spirit quest
function woman_armor:on_interaction()

  if game:get_value("sola_house_gem_quest_finished")then
    game:start_dialog("sola_gem.done.1")
  elseif game:get_value("sola_house_yes") and not game:get_value("sola_house_gem") then
    game:start_dialog("sola_gem.find.1")
  elseif game:get_value("sola_house_yes") and game:get_value("sola_house_gem") then
    game:start_dialog("sola_gem.yes.1", function()
      hero:start_treasure("spirit_gem", 1, "sola_house_gem_quest_finished",function()
        game:start_dialog("sola_gem.wonderful_day.1")
      end)
    end)
  else
    game:start_dialog("sola_gem.hello.1", function(answer)
      if answer == 4 then --No
        game:start_dialog("sola_gem.no.1") 
      elseif answer == 3  then
        game:start_dialog("sola_gem.find.1")  
        game:set_value("sola_house_yes",true)
      end
    end)
  end
end

--Get spirit gem
function pot:on_interaction()
  if not game:get_value("sola_house_gem") then
    hero:start_treasure("spirit_gem", 1, "sola_house_gem")
  end
end

--The pot vanishes if the skeleton save string is "dead".
sol.timer.start(1000, function()
  if game:get_value("sola_house_skeleton") == "dead" then
     flower_wall:set_enabled(false)
     block_pot:set_enabled(false)
     skeleton:set_enabled(false)
  end
  return true  -- To call the timer again (with the same delay).
end)

--Skeleton disabled until save variable is set
  if game:get_value("sola_house_switch_off") == nil then
    skeleton:set_enabled(false)
  end

--Skeleton is enabled. Table and wall entity are disabled. 
  if game:get_value("sola_house_switch_off") == true then
    skeleton:set_enabled(true)
    table_wall:set_enabled(false)
    wall:set_enabled(false)
  end

--Disables everything
  if game:get_value("sola_house_switch_off") == false then
    skeleton:set_enabled(false)
    table_wall:set_enabled(false)
    wall:set_enabled(false)
    flower_wall:set_enabled(false)
  end
end -- end of map on started

--Create on_activated timer
sol.timer.start(2000, function()
  if map.on_activated ~= nil then
    map:on_activated()
 return true 
  end
end)
 
--Timer that checks every 2 seconds
function map:on_activated()  

  --when the skeleton's life reaches zero, the skeleton save string is set.
  if skeleton:get_life() == 0 then
     game:set_value("sola_house_skeleton","dead")
  end

   --The pot vanishes if the skeleton save string is "dead".
  if game:get_value("sola_house_skeleton") == "dead" then
     flower_wall:set_enabled(false)
     block_pot:set_enabled(false)
  end

end -- end of on_activated