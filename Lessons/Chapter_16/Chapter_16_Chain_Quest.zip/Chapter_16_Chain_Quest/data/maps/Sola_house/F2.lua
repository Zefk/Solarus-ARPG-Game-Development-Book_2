-- Lua script of map Sola_house/F2.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()
--Set npc dialog "wall_switch_2" disabled and makes the switch active on return
  if game:get_value("sola_house_switch_off",true) then
    wall_switch_2:set_enabled(false)
    wall_switch:set_activated(true)
  end

--disables npc and sets a save variable
  function wall_switch:on_activated()
    game:set_value("sola_house_switch_off",true)
    wall_switch_2:set_enabled(false)
  end
end


