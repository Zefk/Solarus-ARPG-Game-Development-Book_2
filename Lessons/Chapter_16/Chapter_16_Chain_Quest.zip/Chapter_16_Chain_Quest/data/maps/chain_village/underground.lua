-- Lua script of map chain_village/.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()
local hero = map:get_hero()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()
  game:set_value("boss_map",true)
  game:set_value("scrolling_credits",true)

  function leaver_1:on_activated()
    wall_1:set_enabled(false)
    game:set_value("underground_leaver_1",true)
  end

  if game:get_value("underground_leaver_1") == true then
    leaver_1:set_activated(true)
  end
end

function door_1:on_opened()
  print("opened door")
  hero:teleport("chain_village/underground_miniboss", "boss_destination", "fade")
end

sol.timer.start(1000, function()
  if game:get_value("underground_tapped_3_times") == true then
    bookcase_1:set_enabled(false)
  end
  if door_1:is_opening() == true then
    --hero:teleport("chain_village/underground_miniboss", "boss_destination", "fade")
  end
  return true
end)




