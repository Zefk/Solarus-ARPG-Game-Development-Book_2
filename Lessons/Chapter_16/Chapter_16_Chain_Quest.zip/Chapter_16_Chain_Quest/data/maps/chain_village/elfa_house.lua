-- Lua script of map chain_village/elfa_house.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

--Set a boolean for image
local elfa_separate_cutscene = false

--Load image
local night_background = sol.surface.create("background/fantasy_background.png")

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()

--Cutscene
 if not game:get_value("end_of_cutscene") then
   hero:walk("22222222222")
    local elfa_movement = sol.movement.create("path")
    elfa_movement:set_path({6,6,6,6,6,6,6,6,6,6})
    elfa_movement:set_speed(88)
    elfa_movement:start(elfa, function()
      sol.timer.start(map, 500, function()
        hero:freeze()
        game:start_dialog("elfa_house.elfa", function()
          game:set_hud_enabled(false)
          elfa_separate_cutscene = true
          sol.timer.start(map, 1000, function()
            game:start_dialog("elfa_house.night_background", function()
              sol.timer.start(map, 1000, function()
                game:set_hud_enabled(true)
                elfa_separate_cutscene = false
                hero:unfreeze()
                game:set_value("end_of_cutscene",true)
              end)
            end)
          end)
        end)
      end)
    end)
  end

--Display image
function map:on_draw(dst_surface)
  if elfa_separate_cutscene then
    night_background:draw(dst_surface)
  end
end
   
--Dungeon entrance bookcase
  function bookcase:on_interaction()
    game:start_dialog("elfa_house.bookcase", function() 
      sol.audio.play_sound("switch")
      large_bookcase:set_enabled(false)
    end)
  end
end