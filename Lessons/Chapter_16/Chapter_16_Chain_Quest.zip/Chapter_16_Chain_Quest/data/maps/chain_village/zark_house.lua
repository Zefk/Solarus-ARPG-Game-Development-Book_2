-- Lua script of map chain_village/zark_house.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()

--When slime is dead
--Bookcase vanishes and chest is revealed behind it
  function slime:on_removed()
    if bookcase ~= nil and bookcase:exists() then
      bookcase:set_enabled(false)
    end
    
    if chest ~= nil and chest:exists() then
      if not chest:is_open() then
        sol.audio.play_sound("secret")
      end
    end

    game:set_value("zark_house_enemy_defeated",true)
  end

--Slime and bookcase return check  
  if game:get_value("zark_house_enemy_defeated") == true then
    bookcase:set_enabled(false)
    slime:set_enabled(false)
  end
end

