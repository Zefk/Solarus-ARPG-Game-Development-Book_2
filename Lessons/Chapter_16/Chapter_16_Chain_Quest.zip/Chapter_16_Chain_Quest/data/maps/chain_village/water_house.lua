-- Lua script of map chain_village/water_house.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()

--Interacting with book makes bookcase vanish and reveal wall switch
  function book:on_interaction()
   if not game:get_value("water_house_book") then
    game:start_dialog("water_house.book", function() 
      bookcase:set_enabled(false)
      sol.audio.play_sound("open_lock")
      game:set_value("water_house_book",true)
    end)
   end
  end
 
--Checks if book is active and makes sure the bookcase stays gone when returning to the map.
  if game:get_value("water_house_book") == true then
    bookcase:set_enabled(false)
  end

--Removes wall and its shadow
--Sets wall switch save variable
  function wall_switch:on_activated()
    blockage:set_enabled(false)
    blockage_shadow:set_enabled(false)
    game:set_value("water_house_wall_switch",true)
  end

--Checks to make sure the blockage and shadow is diabled when returning to the map.
  if game:get_value("water_house_wall_switch") == true then
    wall_switch:set_activated(true)
    blockage:set_enabled(false)
    blockage_shadow:set_enabled(false)
  end

--switch 1 enables switch 2 and it appears
  function switch_1:on_activated()
    switch_2:set_enabled(true)
  end

--switch 2 makes a chest appear and plays a sound.
  function switch_2:on_activated()
    chest:set_enabled(true)
    sol.audio.play_sound("secret")
    game:set_value("water_house_floor_switch",true)
  end

--Checks to make sure the chest and switch_2 are not visable when entering the map
  if switch_1:is_activated() == false and switch_2:is_activated() == false then
    chest:set_enabled(false)
    switch_2:set_enabled(false)
  end

--Checks to make sure the switches stay active and the chest/switch_2 is visable on returning to the map
  if game:get_value("water_house_floor_switch") == true then
    switch_1:set_activated(true)
    switch_2:set_activated(true)
    chest:set_enabled(true)
    switch_2:set_enabled(true)
  end
end

