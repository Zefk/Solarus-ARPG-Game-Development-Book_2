-- Lua script of map chain_village/undergrond_miniboss.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest
--Credit Max if you use the following script. <http://forum.solarus-games.org/index.php?action=profile;u=626?>

local map = ...
local game = map:get_game()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()

local switches_on= 0

for switch in map:get_entities("solid") do
  function switch:on_activated()
    switches_on = switches_on + 1
    if switches_on >= 4 then
      switches_on = 0
      timer_sound = sol.timer.start(5000, function() deactivate_switches() end)
      timer_sound:set_with_sound(true)
    end
  end
end

function deactivate_switches()
   for switch in map:get_entities("solid") do
     switch:set_activated(false)
   end
end

end