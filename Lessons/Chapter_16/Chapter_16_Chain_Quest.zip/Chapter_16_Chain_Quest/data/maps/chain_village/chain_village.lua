-- Lua script of map chain_village/chain_villlage.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()
local hero = map:get_hero()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()

--Shows that she is a true hero check
  if game:get_value("shows_heroism") then
    heart_door:set_enabled(true)
  else
    heart_door:set_enabled(false)
  end

--Obtains the spriti shield check
  if game:get_value("spirit_shield") then
    elfa_house_door:set_enabled(true)
  else
    elfa_house_door:set_enabled(false)
  end

-- Call a function every half second.
-- Damaged when overlapping elfa house doorway
sol.timer.start(500, function()
  if hero:overlaps(elfa_house_door) and elfa_house_door:is_enabled() == false then
    sol.audio.play_sound("danger")
    hero:start_hurt(elfa_house_door, 1)
    game:start_dialog("evil_spirit")
    hero:walk("66",false,true)
    hero:set_animation("bubble_stars")
  end
  return true 
end)

  local has_heart_shield = game:has_item("heart_shield")

--Checks if the her has a heart_shield and diables the barrier is she does.
  function sprite:on_interaction()
    if has_heart_shield and not game:get_value("magic_gone") == true then
     game:start_dialog("heart_shown", function()
        game:set_value("shows_heroism",true)
        heart_door:set_enabled(true)
        game:set_value("magic_gone",true)
        sol.audio.play_sound("teleporter")
     end)
    elseif not has_heart_shield then
      game:start_dialog("show_heart")
    end

--A check for when the barrier is removed. A new dialog.
    if game:get_value("magic_gone") == true then
      game:start_dialog("heart_luck")
    end
  end

-- Call a function every second.
--If the heroine tries to enter zark house if barrier is active, then she is flung back with a suprise bubble.
sol.timer.start(100, function()
    if hero:overlaps(magic_info) and not game:get_value("magic_gone") == true then
      hero:walk("66",false,true)
      hero:set_animation("bubble_surprise")
      game:start_dialog("magic_barrier")
    else
      magic_info:set_enabled(false)
    end
  return true 
end)

end -- end of map:on_started()


