-- Lua script of map forest/soulia_forest.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

-- Event called at initialization time, as soon as this map becomes is loaded.
function map:on_started()

--Flower stump
  function flower_switch:on_activated()
    flower_stump:set_enabled(false)
    sol.audio.play_sound("secret")
    game:set_value("flower_stump",true)
  end

--Flower stump check
  if game:get_value("flower_stump") == true then
    flower_stump:set_enabled(false)
    flower_switch:set_activated(true)
  end

--Key stump
  function key:on_interaction()
    if key_chest:is_open() then
      key_stump:set_enabled(false)
      key_stump_hole:set_enabled(false)
      game:set_value("key_stump",true)
      key:set_enabled(false)
      sol.audio.play_sound("open_lock")
    end
  end
  
  if game:get_value("key_stump") == true then
    key_stump:set_enabled(false)
    key_stump_hole:set_enabled(false)
  end

--Bomb stump
  sol.timer.start(1000, function()
  for bomb in map:get_entities_by_type("bomb") do
    if bomb:overlaps(bomb_stump) then
      function bomb:on_removed()
        if bomb_stump ~= nil and bomb_stump:exists() then
          bomb_stump:set_enabled(false)
        end
        sol.audio.play_sound("secret")
        game:set_value("bomb_stump",true)
      end
    end
  end
  return true 
  end)

--Bomb stump check
  if game:get_value("bomb_stump") == true then
    bomb_stump:set_enabled(false)
  end

--block switch
  function hole_block_switch:on_activated()
    game:set_value("hole_block_switch",true)
    hole:set_enabled(false)
    sol.audio.play_sound("secret")
  end

--block switch check
  if game:get_value("hole_block_switch") == true then
    switch_block:set_position(856,668)
    hole_block_switch:set_activated(true)
    hole:set_enabled(false)
  end
end
