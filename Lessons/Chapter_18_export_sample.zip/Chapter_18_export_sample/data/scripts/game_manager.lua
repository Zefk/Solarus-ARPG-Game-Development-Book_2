require("scripts/menus/alttp_dialog_box")
require("scripts/multi_events")
require("scripts/hud/hud")
local save_load_menu = sol.main.load_file("scripts/save_menu.lua")(game)

local game_manager = {}

-- Starts the game from the given savegame file,
-- initializing it if necessary.
function game_manager:start_game()

  function sol.main:on_key_pressed(key)

    if key == "l" then
        sol.menu.start(self, save_load_menu)
    end
  end

end
return game_manager

