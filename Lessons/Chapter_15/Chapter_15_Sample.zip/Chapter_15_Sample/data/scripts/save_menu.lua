--[[
-------------------
SAVE MENU SCRIPT BY: 
-------------------
===================
Zane Kukta (Zefk)
===================

----------------------------
Solarus ARPG Engine Creator:
----------------------------
============================
Christopho
============================

-------------
About Script:
-------------
===========================================================================================================
This is a 3 slot load/save menu script. The player can make newgames and select the save slot they wish.
===========================================================================================================

---------
Features:
---------
===================================================================================================================================
1. Change the action keys, music, and sounds in the change area(s)
2. Load saved game
3. Makes newgames
==================================================================================================================================

---------------------------
Install Instructions: Part 1
---------------------------
========================================================================================
1. Put the save_menu.lua script in the directory "scripts/"
2. Go to main.lua and add the following under the title screen on_finished function.

--------
Example:
--------
  -- Start the game when the Solarus logo menu is finished.
  solarus_logo.on_finished = function()
    -- Show the title screen after the Solarus Logo
    local title_screen_menu = require("scripts/title_screen")
    sol.menu.start(self, title_screen_menu)

    title_screen_menu.on_finished = function()

    local save_load_menu = sol.main.load_file("scripts/save_menu.lua")(game)
    sol.menu.start(self, save_load_menu)

      game_manager:start_game()
    end
  end

3. Put the folder "save_menu" that contains images for the menu in the directory "sprites/"

========================================================================================

----------------------------
Install Instructions: Part 2
----------------------------

1. Add the following in the game manager. 
--------
Example:
--------
require("scripts/menus/alttp_dialog_box")
require("scripts/multi_events")
require("scripts/hud/hud")
local save_load_menu = sol.main.load_file("scripts/save_menu.lua")(game)

local game_manager = {}

-- Starts the game from the given savegame file,
-- initializing it if necessary.
function game_manager:start_game()

  function sol.main:on_key_pressed(key)

    if key == "l" then
        sol.menu.start(self, save_load_menu)
    end
  end

end
return game_manager

2.Game functions only work in the save_menu.lua under game:start(). I suggest making a menu with the default "d" pause key. The menu would be where the player would load and save the game. At the moment the "d" key saves the game in the sample.

=============================================================================================================================================

-------------------
Usage Instructions:
-------------------
====================================================================================================================================
1.Use the up and down keys
2.Change the action key to what you desire in the change area. By default it is key "a", reset with "s", and in game clear with "q".
3.Key "L" activates the save menu in game and key "q" can clear it. 
====================================================================================================================================

-----------------------
Script Completion Date:
-----------------------
==============================
4-6-17 [April 6th, 2017]
==============================

--------
License: 
--------
=============================================================================================================================================
Free under GPLv3 by default. It uses Solarus functions and Solarus is under GPLv3. Credit the (2) people involved in script and link to their websites.

---------
Websites:
---------
Zane Kukta (Zefk) <http://zelzec-entertainment.weebly.com/>
Christopho <http://www.solarus-games.org/>
=============================================================================================================================================
--]]

--Make a table for a menu
local save_load_menu = {}



--Table for the variables
local save_menu ={

--Variables for up and down browsing
   browse_slot = 0,
   browse_newgame_continue = 0,
   browse_yes_no = 0,
   up = 0,
   down = 0,

--Creating surface/loading images
   bg_img = sol.surface.create("save_menu/background.png"),
   idle_img = sol.surface.create("save_menu/Idle.png"),
   hover_img = {},
   slot_img = {},
   bg_small_img = sol.surface.create("save_menu/bg_small.png"),
   idle_cont_ng_img = sol.surface.create("save_menu/Continue_newgame_idle.png"),
   continue_hover_img = sol.surface.create("save_menu/continue_hover.png"),
   newgame_hover_img = sol.surface.create("save_menu/newgame_hover.png"),
   new_game_question_img = sol.surface.create("save_menu/newgame_question.png"),
   yes_hover_img = sol.surface.create("save_menu/yes_hover.png"),
   no_hover_img = sol.surface.create("save_menu/no_hover.png"),

--Variable for showing green background image
   bg = true,

--Variable for showing the green idle boxes
   idle = true,

--Variable for showing green semi-transparent hover images
   hover = {},

--Variable for showing slot text images
   slot = {},

--Variable for showing the small background image menu
   bg_small = false,

--Variable for showing the continue and newgame images on the small background menu
   idle_cont_ng = false,

--Variables for showing newgame and continue hover images
   continue_hover = false,
   newgame_hover = false,

--Variable for showing the "are you sure you.... yes/no" image
   new_game_question = false,

--Variable for showing yes and no hover images
   yes_hover = false,
   no_hover = false,

--Variables for allowing/disallowing the slot semi-transparent images to go up and down.
   up_slot = true,
   down_slot = true,

--Variables for allowing/disallowing the newgame and continue hover images to go up and down.
   up_newgame_continue = false,
   down_newgame_continue = false,

--Variables for allowing/disallowing the yes and no over images to go up and down.
   up_yes_no = false,
   down_yes_no = false,

--Turns on/off the save and load section of the script.
   save_load_off = false,

--Turns on/off the slot browsing section of the script
   slots_on = true,

--Turns on/off the continue and newgame section of the script
   continue_newgame_on = false,

--Turns on/off the yes and no section of the script
   yes_no_on = false,

--Sounds for action
	 continue_sound = "none",
	 newgame_sound = "none",

	 yes_sound = "none",
	 no_sound = "none",

   slot_sound = "none",
  
   reset_sound = "none",

   in_game_clear_sound = "none",

--Sounds for up and down keys
   continue_up_sound = "none",
	 newgame_down_sound = "none",

	 yes_up_sound = "none",
	 no_down_sound = "none",

   slot_up_sound = "none",
   slot_down_sound = "none",

--keys for action
	 continue_action = "none",
	 newgame_action = "none",

	 yes_action = "none",
	 no_action = "none",

   slot_action = "none",
  
   reset_action = "none",

   in_game_clear_action = "none",  

}

--stop title screen music
sol.audio.stop_music()

--=================================================================================================
--CHANGE SETTINGS AREA_1:

--Start save_menu music
sol.audio.play_music("diarandor/castle")

--Action sounds
save_menu.continue_sound = "pause_closed"
save_menu.newgame_sound = "pause_closed"

save_menu.yes_sound = "pause_closed"
save_menu.no_sound = "pause_closed"

save_menu.slot_sound = "pause_closed"
  
save_menu.reset_sound = "pause_closed"

save_menu.in_game_clear_sound = "pause_closed"

--Up and down sounds
save_menu.continue_up_sound = "cursor"
save_menu.newgame_down_sound = "cursor"

save_menu.yes_up_sound = "cursor"
save_menu.no_down_sound = "cursor"

save_menu.slot_up_sound = "cursor"
save_menu.slot_down_sound ="cursor"

--keys for action
save_menu.continue_action = "a"
save_menu.newgame_action = "a"

save_menu.yes_action = "a"
save_menu.no_action = "a"

save_menu.slot_action = "a"
  
save_menu.reset_action = "s"

save_menu.in_game_clear_action = "q" 

--=================================================================================================

--Reset and restart the save menu when it is activated again
function save_load_menu:on_started()
   sol.audio.stop_music()

--=================================================================================================
--CHANGE SETTINGS AREA_2:
   sol.audio.play_sound("pause_closed")

   sol.audio.play_music("diarandor/castle")

	 --Action sounds
	 save_menu.continue_sound = "pause_closed"
	 save_menu.newgame_sound = "pause_closed"

	 save_menu.yes_sound = "pause_closed"
	 save_menu.no_sound = "pause_closed"

	 save_menu.slot_sound = "pause_closed"
		
	 save_menu.reset_sound = "pause_closed"

	 save_menu.in_game_clear_sound = "pause_closed"

	 --Up and down sounds
	 save_menu.continue_up_sound = "cursor"
	 save_menu.newgame_down_sound = "cursor"

	 save_menu.yes_up_sound = "cursor"
	 save_menu.no_down_sound = "cursor"

	 save_menu.slot_up_sound = "cursor"
	 save_menu.slot_down_sound ="cursor"

	 --keys for action
	 save_menu.continue_action = "a"
	 save_menu.newgame_action = "a"

	 save_menu.yes_action = "a"
	 save_menu.no_action = "a"

	 save_menu.slot_action = "a"
		
	 save_menu.reset_action = "s"

	 save_menu.in_game_clear_action = "q" 

--=================================================================================================
   save_menu.bg = true
   save_menu.idle = true
   save_menu.up_slot = true
   save_menu.down_slot = true
   save_menu.slots_on = true
   save_menu.browse_slot = 0
   save_menu.browse_newgame_continue = 0
   save_menu.browse_yes_no = 0

		--Start hovering on slot 1
		if save_menu.browse_slot == 0 then
			save_menu.hover[0] = true
			save_menu.hover[1] = false
			save_menu.hover[2] = false
		
			save_menu.slot[0] = true
			save_menu.slot[1] = false
			save_menu.slot[2] = false
		end

   save_menu.bg_small = false

   save_menu.idle_cont_ng = false
   save_menu.continue_hover = false
   save_menu.newgame_hover = false

   save_menu.new_game_question = false
   save_menu.yes_hover = false
   save_menu.no_hover = false

   save_menu.up_slot = true
   save_menu.down_slot = true

   save_menu.up_newgame_continue = false
   save_menu.down_newgame_continue = false

   save_menu.up_yes_no = false
   save_menu.down_yes_no = false

   save_menu.save_load_off = false
   save_menu.continue_newgame_on = false
   save_menu.yes_no_on = false

end

--Create hover images for slots
  for rep = 0,2 do
   save_menu.hover_img[rep] = sol.surface.create("save_menu/"..rep..".png")
  end

--ceate text images for slots
  for rep = 0,2 do
   save_menu.slot_img[rep] = sol.surface.create("save_menu/slot"..rep..".png")
  end

--Start hovering on slot 1
if save_menu.browse_slot == 0 then
  save_menu.hover[0] = true
  save_menu.hover[1] = false
  save_menu.hover[2] = false
  
  save_menu.slot[0] = true
  save_menu.slot[1] = false
  save_menu.slot[2] = false
end


--The draw function for showing images
function save_load_menu:on_draw(screen)

--Start hovering on continue
if save_menu.continue_newgame_on == true then
  if save_menu.browse_newgame_continue == 0 then
    save_menu.continue_hover = true
    save_menu.newgame_hover = false
  end
end

--Start hovering on yes
if save_menu.yes_no_on == true then
  if save_menu.browse_yes_no == 0 then
    save_menu.yes_hover = true
    save_menu.no_hover = false
  end
end

--Show background when conditions are true
   if save_menu.bg == true then
     save_menu.bg_img:draw(screen)
   end

--Show idle text when conditions are true
   if save_menu.idle == true then
     save_menu.idle_img:draw(screen)
   end

--Show hover images when conditions are true
   for rep = 0,2 do
    if save_menu.hover[rep] == true then
     save_menu.hover_img[rep]:draw(screen)
    end
   end

--Show slot text when conditions are true
   for rep = 0,2 do
    if save_menu.slot[rep] == true then
     save_menu.slot_img[rep]:draw(screen)
    end
   end

--Show small background image when conditions are true
   if save_menu.bg_small == true then
     save_menu.bg_small_img:draw(screen)
   end

--Show idle continue newgame image when conditions are true
   if save_menu.idle_cont_ng == true then
     save_menu.idle_cont_ng_img:draw(screen)
   end

--Show continue hover image when conditions are true
   if save_menu.continue_hover == true then
     save_menu.continue_hover_img:draw(screen)
   end

--Show newgame hover image when conditions are true
   if save_menu.newgame_hover == true then
     save_menu.newgame_hover_img:draw(screen)
   end

--Show question image when conditions are true
   if save_menu.new_game_question == true then
     save_menu.new_game_question_img:draw(screen)
   end

--Show no-hover image when conditions are true
   if save_menu.no_hover == true then
     save_menu.no_hover_img:draw(screen)
   end

--Show yes-hover image when conditions are true
   if save_menu.yes_hover == true then
     save_menu.yes_hover_img:draw(screen)
   end

end -- End of draw function

--key function for pressing buttons
function save_load_menu:on_key_pressed(key)

--Go down slot
  if key == "down" and save_menu.up_slot == true then
    sol.audio.play_sound(save_menu.slot_up_sound)
    if save_menu.browse_slot < 2 then
      save_menu.browse_slot = save_menu.browse_slot + 1
    end
  end

--Go up slot
  if key == "up" and save_menu.down_slot == true then
    sol.audio.play_sound(save_menu.slot_down_sound)
    if save_menu.browse_slot > 0 then
      save_menu.browse_slot = save_menu.browse_slot - 1
    end
  end

--Go down newgame/continue
  if key == "down" and save_menu.up_newgame_continue == true then
    sol.audio.play_sound(save_menu.continue_up_sound)
    if save_menu.browse_newgame_continue < 1 then
      save_menu.browse_newgame_continue = save_menu.browse_newgame_continue + 1
    end
  end

--Go up newgame/continue
  if key == "up" and save_menu.down_newgame_continue == true then
    sol.audio.play_sound(save_menu.newgame_down_sound)
    if save_menu.browse_newgame_continue > 0 then
      save_menu.browse_newgame_continue = save_menu.browse_newgame_continue - 1
    end
  end


--Go down yes/no
  if key == "down" and save_menu.up_yes_no == true then
    sol.audio.play_sound(save_menu.yes_up_sound)
    if save_menu.browse_yes_no < 1 then
      save_menu.browse_yes_no = save_menu.browse_yes_no + 1
    end
  end

--Go up yes/no
  if key == "up" and save_menu.down_yes_no == true then
    sol.audio.play_sound(save_menu.no_down_sound)
    if save_menu.browse_yes_no > 0 then
      save_menu.browse_yes_no = save_menu.browse_yes_no - 1
    end
  end

--A function for resetting the menu back to slot selection
		function reset()

			--Clear hover images
			save_menu.continue_hover = false
			save_menu.newgame_hover = false

			save_menu.yes_hover = false
			save_menu.no_hover = false

			--Clear small background
			save_menu.bg_small = false

			--Clear text
			save_menu.idle_cont_ng = false
			save_menu.new_game_question = false

			--Clear up down locks
			save_menu.up_slot = true
			save_menu.down_slot = true

			save_menu.up_yes_no = false
			save_menu.down_yes_no = false

			save_menu.up_newgame_continue = false
			save_menu.down_newgame_continue = false

			--Clear browse to default
			save_menu.browse_newgame_continue = 0
			save_menu.browse_yes_no = 0

      --Turn off newgame menu
      save_menu.continue_newgame_on = false
     
      save_menu.slots_on = true

      save_menu.yes_no_on = false 
		end

--Function for clearing the save game menu. Completly stops the menu.
	  function clear()

				--Clear hover images
				save_menu.continue_hover = false
				save_menu.newgame_hover = false

        save_menu.hover[0] = false
        save_menu.hover[1] = false
        save_menu.hover[2] = false

				save_menu.yes_hover = false
				save_menu.no_hover = false

				--Clear backgrounds
				save_menu.bg_small = false
        save_menu.bg = false
        save_menu.idle = false

				--Clear text
				save_menu.idle_cont_ng = false
				save_menu.new_game_question = false

        --clear slots
        save_menu.slot[0] = false
        save_menu.slot[1] = false
        save_menu.slot[2] = false

				--Clear up/down slot locks
				save_menu.up_slot = false
				save_menu.down_slot = false

				--Clear up/down yes/no locks
				save_menu.up_yes_no = false
				save_menu.down_yes_no = false

				--Clear up/down continue/newgame locks
				save_menu.up_newgame_continue = false
				save_menu.down_newgame_continue = false

				--Clear browse to default
				save_menu.browse_newgame_continue = 0
				save_menu.browse_yes_no = 0

		    --Turn off newgame menu
		    save_menu.continue_newgame_on = false

        --Turn of slot display
        save_menu.slots_on = false

        --Turn off save_load
        save_menu.save_load_off = true

        --Turn off yes/no
        save_menu.yes_no_on = false
			end

			--Clear and stop the menu when playing the game.
			if key == save_menu.in_game_clear_action then
				sol.audio.play_sound(save_menu.in_game_clear_sound)
				sol.menu.stop(self, save_load_menu)
				clear()
			end

--This function activates the newgame/continue menu and disables the slot menu
      function newgame_continue()
		   --Activate small black background and idle newgame/continue text
			 save_menu.bg_small = true
			 save_menu.idle_cont_ng = true
			 
		   --Deactivate slot up/down keys
			 save_menu.up_slot = false
			 save_menu.down_slot = false

		   --Activate continue and newgame up/down keys 
			 save_menu.up_newgame_continue = true
			 save_menu.down_newgame_continue = true
      end

--This function activates the yes/no/question menu and disables the continue/newgame menu.
      function yes_no_question()

    		save_menu.idle_cont_ng = false

				save_menu.up_newgame_continue = false
				save_menu.down_newgame_continue = false

				save_menu.continue_hover = false
				save_menu.newgame_hover = false

				save_menu.up_yes_no = true
				save_menu.down_yes_no = true
				save_menu.new_game_question = true

        save_menu.yes_no_on = true

        save_menu.continue_newgame_on = false
        save_menu.slots_on = false
      end

--Allows/disallow save menu to function.
if save_menu.save_load_off == false then

--An array for 3 slots and 3 saves
for rep = 0, 2 do

	--The following happens on the slot that is browsed
	if save_menu.browse_slot == rep then


	  --Show slot hover image
		save_menu.hover[0 + rep] = true
		save_menu.hover[1 - rep] = false
		save_menu.hover[3 - rep] = false

	  --Show slot text
		save_menu.slot[0 + rep] = true
		save_menu.slot[1 - rep] = false
		save_menu.slot[3 - rep] = false


      --The following happens when yes and no is activated.
			if save_menu.yes_no_on == true then

        --0 = yes
        --Old save is deleted and a newgame is created. 
				if save_menu.browse_yes_no == 0 then
					save_menu.yes_hover = true
					save_menu.no_hover = false

					if key == save_menu.yes_action then
            --Play action sound for yes
            sol.audio.play_sound(save_menu.yes_sound)

            --Remove save file
            sol.file.remove("save"..rep..".dat")
						local exists = sol.game.exists("save"..rep..".dat")
						local game = sol.game.load("save"..rep..".dat")
						if not exists then
							--Initialize a new savegame

							game:set_max_life(12)
							game:set_life(game:get_max_life())
							game:set_ability("lift", 2)
							game:set_max_money(100)
							game:set_ability("sword", 2)
							game:set_ability("sword_knowledge", 1)
							game:set_ability("shield", 1)
							game:set_ability("swim", 1)
							game:set_ability("jump_over_water", 1)
							game:set_starting_location("Map_4", "starting_destination") -- Starting location.
						end
							game:start()

            local game_manager = require("scripts/game_manager")

            game_manager:manage(game)

            --Stop and clear the menu
            sol.menu.stop(self, save_load_menu)
						clear()
					end
				end

        --1 = no
        --menu is reset back to slot selection
				if save_menu.browse_yes_no == 1 then

					save_menu.yes_hover = false
					save_menu.no_hover = true

					if key == save_menu.no_action then
            sol.audio.play_sound(save_menu.no_sound)
						reset()
					end
				end
			end

			--Activate newgame/continue hover images
			if save_menu.continue_newgame_on == true then

        --0 = continue
				--Continue hover
				if save_menu.browse_newgame_continue == 0 then

					save_menu.continue_hover = true
					save_menu.newgame_hover = false 
          --Continues on a save file.
		      if key == save_menu.continue_action then
            --Play action sound for continue
            sol.audio.play_sound(save_menu.continue_sound)
						local exists = sol.game.exists("save"..rep..".dat")
						local game = sol.game.load("save"..rep..".dat")
						if not exists then
							--Initialize a new savegame

							game:set_max_life(12)
							game:set_life(game:get_max_life())
							game:set_ability("lift", 2)
							game:set_max_money(100)
							game:set_ability("sword", 2)
							game:set_ability("sword_knowledge", 1)
							game:set_ability("shield", 1)
							game:set_ability("swim", 1)
							game:set_ability("jump_over_water", 1)
							game:set_starting_location("Map_4", "starting_destination") -- Starting location.
						end
							game:start()

             local game_manager = require("scripts/game_manager")
             game_manager:manage(game)

            --Stop and clear the menu
            sol.menu.stop(self, save_load_menu)
            clear()
		      end
				end
			
        --1 = newgame
				--Newgame hover and activates "are you sure you....yes/no"
				if save_menu.browse_newgame_continue == 1 then

					save_menu.continue_hover = false
					save_menu.newgame_hover = true

		      if key == save_menu.newgame_action then
            --Play this sound on "newgame"
            sol.audio.play_sound(save_menu.newgame_sound)
            yes_no_question()
		      end
				end
			end

		  --Activate continue/newgame menu and turn off slot up/down keys
			if key == save_menu.slot_action and save_menu.slots_on == true then
        sol.audio.play_sound(save_menu.slot_sound)

       newgame_continue()

       --Turn on newgame menu
       save_menu.continue_newgame_on = true
			end

	--Reset to slot selection
		if key == save_menu.reset_action then
      sol.audio.play_sound(save_menu.reset_sound)
      reset()
		end
  end -- slot 3 end
end -- save_load_off end
end -- end of loop

end

return save_load_menu -- Return save menu
