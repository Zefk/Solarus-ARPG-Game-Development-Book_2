-- Lua script of map Map_4.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()
local hero = map:get_hero()
local camera = map:get_camera()


function door_trigger:on_activated()
  map:open_doors("switch_door")
  sol.audio.play_sound("door_open")
end

							game:set_ability("sword_knowledge", 0)


function map:on_started()

--Jump
 local jump = sol.movement.create("jump")

 jump:set_direction8(2)
 jump:set_distance(100)
 jump:start(elf_2)

--Random_Path
 local random_path = sol.movement.create("random_path")

 random_path:start(elf)


--Target
--Default target is hero
 local target = sol.movement.create("target")
 target:set_speed(32)
 target:start(elf_4)

--Follow sprite "elf"
 local target2 = sol.movement.create("target")

 target2:set_speed(32)
 target2:start(elf_5)
 target2:set_target(elf)


--Path finding (Go around obsticles)
 local path = sol.movement.create("path_finding")

 path:set_speed(69)
 path:start(elf_6)
 path:set_target(hero)

--Random
 local straight_random = sol.movement.create("random")

straight_random:start(elf_7)

--Straight
 local straight = sol.movement.create("straight")
straight:set_angle(3)
straight:start(elf_3)

--Path
 local path = sol.movement.create("path")

path:set_path{3,0,3,0,3,0,3,0,3,0,3,0,3,0,3,0,3}
path:set_speed(80)
path:set_loop(true)
path:set_ignore_obstacles(true)
path:start(elf_8)

--Pixel movement
 local pixel = sol.movement.create("pixel")

pixel:set_trajectory{{5,-5},{0,-1}}
pixel:set_loop(true)
pixel:set_ignore_obstacles(true)
pixel:start(elf_9)

--Circle movement
local circle = sol.movement.create("circle")
circle:set_center(test)
circle:set_loop_delay(1000)
circle:set_angle_speed(100)
circle:set_duration(1000000)
circle:set_max_rotations(100)
circle:set_initial_angle(100)
circle:set_clockwise(true)
circle:set_radius(22)
circle:set_radius_speed(1)
circle:set_ignore_obstacles(false)
circle:start(elf_10)
 
end

elf_4:set_traversable(true)
elf_6:set_traversable(true)

local example = {}
local test = {}
local map_functions = false

--Name of the map
example[1] = "Map: "..map:get_id()

--Name of the world
example[2] = "World: "..map:get_world()

--Floor number
example[3] = "Floor: "..map:get_floor()

--coorndinates in the world
example[4] = "Location: "..map:get_location()

--Name of tileset
example[5] = "Tieset: "..map:get_tileset()

--Name of music playing
example[6] = "Music playing: "..map:get_music()


--Display text
for rep = 1,6 do
--http://www.solarus-games.org/doc/latest/lua_api_text_surface.html
      test[rep] = sol.text_surface.create({ -- name a local variable something and assign it to the sol.text_surface
      font = "minecraftia", -- font name
      text = example[rep], -- text you want to show
      font_size = 12, -- font size obviously
      rendering_mode = "antialiasing", -- "solid" (faster) and default
      color = {240,248,255}, -- color must be in a table RGB (http://www.rapidtables.com/web/color/RGB_Color.htm)
    })
end

function sol.main:on_draw(screen)

  if map_functions == true then
     test[1]:draw(screen,10, 15)
     test[2]:draw(screen,10,30)
     test[3]:draw(screen,10,45)
     test[4]:draw(screen,10,60)
     test[5]:draw(screen,10,75)
     test[6]:draw(screen,10,90)
  end

end --end of draw function



function map:on_key_pressed(key)    
    
    local path = sol.movement.create("path")
    
    path:set_path{2,0,2,0,3,0,3,0,3,0,3,0,3,0,3,0,3}
    path:set_speed(80)
    path:set_loop(false)
    path:set_ignore_obstacles(true)

   if key == "l" then
       game:set_suspended(true)
   end

   if key == "q" then
       game:set_suspended(false)
       sol.audio.play_music(map:get_music())
   end

    if key == "1" then
    --Camera size goes by 8
        camera:set_size(96, 96)
        camera:start_tracking(elf_6)
        camera:set_position_on_screen(0,0)
    end

    if key == "2" then
        camera:set_size(320, 240)
        camera:set_position_on_screen(0,0)
        camera:start_tracking(hero)
    end

    if key == "3" then
        camera:set_size(320, 240)
        --Camera default position is 0,0
        camera:set_position_on_screen(120,60)
        camera:start_tracking(hero)
    end

    if key == "4" then
     --Use movements on camera
        path:start(map:get_camera())
        camera:set_position_on_screen(0,0)
    end
    
    if key == "5" then
        map_functions = true
    end

    if key == "6" then
        map_functions = false
    end

end


-------------file:write(), file:read(), and search for string.
local coordinate_x = 50
local coordinate_y = 40
local file_write = sol.file.open("example.txt", "w")
file_write:write("x:",coordinate_x, "y:", coordinate_y)
file_write:close()

local file_read = sol.file.open("example.txt", "r")
local line = file_read:read()
print(line)

        if string.find(line,"0") then
                print("zero")
        end
file_read:close()

-------------file:read(format)
local file_make_file2 = sol.file.open("file2.txt", "w")

file_make_file2:write("The apple\nThe orange.\nThe limon.\nThe pear.\n")
file_make_file2:close()

local file_read_all = sol.file.open("file2.txt", "r")

local line2 = file_read_all:read("*a")
print(line2)
file_read_all:close()


-------------file:seek()
local file_seek = sol.file.open("example.txt", "r")

--x:50y:40 in example.txt. -2 would be two from the end. (40)
file_seek:seek("end",-2)

local value = file_seek:read()

--Convert string "40" to the number value 40
print("The variable is:"..tonumber(value))

--Add 5 onto the value
print("The variable is:"..value + 5)

file_seek:close()

--It might be easier to just store your values in a save file. 
game:set_value("coordinate_z", 50)
print("Coordinate Z is: "..game:get_value("coordinate_z"))

game:set_value("coordinate_question", "what")
print("Coordinate Question is: "..game:get_value("coordinate_question"))

--Read line function
local function readLines(sPath)
  local file = sol.file.open(sPath, "r")
  if file then
        local tLines = {}
        local sLine = file:read()
        while sLine do
          table.insert(tLines, sLine)
          sLine = file:read()
        end
        file:close()
        return tLines
  end
  return nil
end

--Write line function
local function writeLines(sPath, tLines)
  local file = sol.file.open(sPath, "w")
  if file then
        for _, sLine in ipairs(tLines) do
          file:write(sLine)
        end
        file:close()
  end
end

local file_make_test = sol.file.open("test.txt", "w")
file_make_test:close()


local tLines = readLines("test.txt") -- Read this file
table.insert(tLines, "This is the first line!\n") -- Line 1
tLines[2] = "This is line 2!\n" -- Line 2
tLines[3] = "This is line 3!\n" -- Line 3
tLines[4] = 50 -- Line 4

table.remove(tLines, 2) -- Remove line 2
writeLines("test.txt", tLines) --Write lines to this file
print("Lines in the file: ", #tLines) --Print number of lines

--Open file. You must open the file to get the value
local tLines = readLines("test.txt") -- Read this file

--Print line 3. Line 4 will not be 50 because we removed line 2. That means line 3 will be 50.
print("Line 4 value is: "..tLines[3])


