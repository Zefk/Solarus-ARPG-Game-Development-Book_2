-- Lua script of map first_map.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()

function map:on_started()
  hero:start_jumping(2, 100, false)
end

-- Call a function every second.
sol.timer.start(1000, function()
    if hero:get_animation() == "walking" then
      print("walking")
    end
  return true  -- To call the timer again (with the same delay).
end)


-- Call a function every second.
sol.timer.start(1000, function()
    if hero:get_animation() == "walking" then
      hero:set_animation("stopped")
    else
      hero:set_animation("walking")
    end
  return true  -- To call the timer again (with the same delay).
end)

