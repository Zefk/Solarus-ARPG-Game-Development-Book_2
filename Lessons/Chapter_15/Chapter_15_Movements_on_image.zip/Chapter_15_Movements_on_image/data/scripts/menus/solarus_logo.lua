local solarus_logo_menu = {}

local logo_img = sol.surface.create("menus/solarus_logo.png")

function solarus_logo_menu:on_started()

  local movement = sol.movement.create("straight")
  movement:set_speed(128)
  movement:set_angle(3 * math.pi / 2)
  movement:set_max_distance(240)
  movement:start(logo_img, function()
    sol.menu.stop(solarus_logo_menu)
  end)
end

function solarus_logo_menu:on_draw(screen)
  logo_img:draw(screen, 0, -240)
end

function solarus_logo_menu:on_key_pressed(key)
  if key == "space" then
    sol.menu.stop(solarus_logo_menu)
  end
end

return solarus_logo_menu
