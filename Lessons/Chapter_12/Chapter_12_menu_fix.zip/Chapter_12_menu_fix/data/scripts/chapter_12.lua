--[[
-------------
Instructions:
-------------
==================================================================================
Press keys "up" and "down"
Press "m" to activate. (See game_manager.lua)
==================================================================================
--]]

local menu = {}
 
function menu:button_menu(game)

--Creating surfaces for the images and loading in the images.
local overlay = sol.surface.create ("overlay.png")
local button_menu = sol.surface.create ("menu.png")
local down_up = 0
local direction = 0

--Function for drawing or showing images
function menu:on_draw(screen)
   overlay:draw(screen,0,down_up)
   button_menu:draw(screen)
end -- end of draw function

--Solarus key pressing function
function menu:on_key_pressed(key)
--Pause the game
game:set_paused(true)

if key == "up" then
  if direction > 0 then
    direction = direction - 1
    down_up = down_up - 27 - 0.7
    print("UP: "..direction.." down_up: "..down_up)
  end
end

if key == "down" then
  if direction < 6 then
    direction = direction + 1
    down_up = down_up + 27 + 0.7
    print("Down: "..direction.." down_up: "..down_up)
  end
end

if key == "e" then
  if direction == 0 then
    print("Item Menu ON!")
  end

  if direction == 1 then
    print("Skills Menu ON!")
  end

  if direction == 2 then
    print("Equipment Menu ON!")
  end

  if direction == 3 then
    print("Status Menu ON!")
  end

  if direction == 4 then
    print("Formation Menu ON!")
  end

  if direction == 5 then
    print("Save Menu ON!")
  end

  if direction == 6 then
    print("Logout Menu ON!")
  end
end

end -- end of key press function



end --end of button menu function

return menu
