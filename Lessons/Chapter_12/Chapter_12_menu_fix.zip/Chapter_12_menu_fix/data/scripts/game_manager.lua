local game_manager = {}
local on = true

local menu = require("scripts/chapter_12.lua")
local initial_game = require("scripts/initial_game")
require("scripts/menus/alttp_dialog_box")

-- Starts the game from the given savegame file,
-- initializing it if necessary.

function game_manager:start_game()
  local exists = sol.game.exists("save1.dat")
  local game = sol.game.load("save1.dat")
  if not exists then
    -- Initialize a new savegame.
    game:set_max_life(12)
    game:set_life(game:get_max_life())
    game:set_ability("lift", 2)
    game:set_ability("sword", 1)
  end

menu:button_menu(game)

function game:on_key_pressed(key)
  if key == "m" then  

    if on == true then
      sol.menu.start(game, menu)
      print("m")
      on = false
    end
  end

  if key == "s" then
    sol.menu.stop(menu)
    on = true
  end
end


  game:start()

  local hero = game:get_hero()
  hero:set_tunic_sprite_id("main_heroes/eldran")
end

return game_manager

