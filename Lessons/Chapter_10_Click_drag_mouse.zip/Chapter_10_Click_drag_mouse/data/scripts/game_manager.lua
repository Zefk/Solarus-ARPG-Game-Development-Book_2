local game_manager = {}

local initial_game = require("scripts/initial_game")
require("scripts/menus/alttp_dialog_box")

-- Starts the game from the given savegame file,
-- initializing it if necessary.

function game_manager:start_game()

  local exists = sol.game.exists("save1.dat")
  local game = sol.game.load("save1.dat")
  if not exists then
    -- Initialize a new savegame.
    game:set_max_life(12)
    game:set_life(game:get_max_life())
    game:set_ability("lift", 2)
    game:set_ability("sword", 1)
  end

  sol.main.load_file("scripts/chapter_10.lua")(game)

  game:start()

  local hero = game:get_hero()
  hero:set_tunic_sprite_id("main_heroes/eldran")
end

return game_manager

