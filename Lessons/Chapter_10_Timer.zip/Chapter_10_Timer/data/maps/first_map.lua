--[[
--------------
Instructions:
--------------
============================================================================================================
Key "o" to stop some timers.
============================================================================================================
--]]
local map = ...
local game = map:get_game()

--[[
--Timer will go off (as long as you are still on the same map) in 5 seconds. 5000 milliseconds is 5 seconds.
--Timer will not go off if you go to another map before 5 seconds are reached.
--If the game is paused with "d", then the timer is paused as well.
sol.timer.start(5000, function()
  sol.audio.play_sound("secret")
end)

--Using the "game" context or parameter will make the timer go off even though you leave the map.
--context (map, game, item, map entity, menu or sol.main; optional)
--
sol.timer.start(game, 5000, function()
  sol.audio.play_sound("secret")
end)


local sup_timer =  sol.timer.start(5000, function()
  sol.audio.play_sound("secret")
end)

--Unsuspend the timer. You can do this if you do not want to use the game parameter or context.
--You can use suspend with map too: "timer:is_suspended_with_map(false)"
sup_timer:set_suspended(false)


-- Call a function half second.
sol.timer.start(500, function()
  sol.audio.play_sound("cane")
  return true  -- To call the timer again (with the same delay).
end)


--]]
-- Call a function half second with a number value variable
--Press "o" to stop the timer
local variable_1 = 0
sol.timer.start(500, function()
  sol.audio.play_sound("cane")
  return variable_1 ~= 1
end)
--[[


-- Call a function half second with a true/false
--Press "o" to stop the timer
local on = true
sol.timer.start(500, function()
  sol.audio.play_sound("cane")
  return on == true
end)


-- Call a function ten times, with half second between each call.
local num_calls = 0
sol.timer.start(500, function()
  sol.audio.play_sound("bomb")
  num_calls = num_calls + 1
  return num_calls < 3
end)
--]]

--Solarus key pressing function
function sol.main:on_key_pressed(key)

if key == "o" then
  on = false
  variable_1 = 1
  print(variable_1)
end

  
end -- end of key press function

