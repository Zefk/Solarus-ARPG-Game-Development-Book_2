-- Lua script of custom entity NPC.
-- Basic follower script

local entity = ...
local game = entity:get_game()
local map = entity:get_map()
local hero = map:get_hero()
local sprite
local movement
local path_finding

function entity:on_obstacle_reached()

   movement = sol.movement.create("path_finding")
   movement:set_target(hero)
   movement:set_speed(88)
   movement:start(entity)

local distance_between = hero:get_distance(entity)
  if distance_between < 25 then
     movement = sol.movement.create("target")
     movement:set_target(hero)
     movement:set_speed(88)
     movement:start(entity)
  end
end

-- Event called when the custom entity is initialized.
function entity:on_created()
   sprite = entity:create_sprite("citizens/village_woman_2")
   self:set_traversable_by(true)
   entity:set_can_traverse("hero", false)

   movement = sol.movement.create("target")
   movement:set_target(hero)
   movement:set_speed(88)
   movement:start(entity)
end

function entity:on_movement_changed()

   sprite:set_direction(movement:get_direction4())   
end
