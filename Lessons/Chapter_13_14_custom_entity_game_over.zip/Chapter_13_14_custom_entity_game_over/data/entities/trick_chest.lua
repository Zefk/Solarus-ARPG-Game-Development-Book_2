-- Lua script of custom entity test.
-- This script is executed every time a custom entity with this model is created.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation for the full specification
-- of types, events and methods:
-- http://www.solarus-games.org/doc/latest

local entity = ...
local map = entity:get_map()
local game = entity:get_game()
local hero = map:get_hero()

function entity:on_created()
  --self:set_size(16, 16)
  --self:set_origin(8, 13)
  self:set_traversable_by(true)
entity:get_sprite():set_animation("big")
end


function entity:on_interaction()
  --game:remove_life(12 - 6)
  --entity:remove()
  --hero:start_hurt(240,277,6)
end


--[[
sol.timer.start(400, function()
  if entity.on_activated ~= nil then
    entity:on_activated()
 return true 
  end
end)


function entity:on_activated()
  if hero:overlaps(entity) then
    sol.audio.play_sound("secret")
    hero:start_hurt(240,277,6)
  end
end

--]]


--Create on_activated
sol.timer.start(500, function()
  if entity.on_activated ~= nil then
    entity:on_activated()
 return true 
  end
end)
 
--if hero's position is equal to entity's position, then hero is damaged when stepping on entity.
function entity:on_activated()
local x1,y1 = hero:get_position()
--print("Hero: "..x1..","..y1)
  if (x1 > 240 and x1 < 256) and (y1 > 272 and y1 < 288) then
    sol.audio.play_sound("secret")
    hero:start_hurt(240,277,6)
  end
end

