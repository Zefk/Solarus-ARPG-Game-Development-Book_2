--[[
---------------------
TITLE SCREEN MENU BY: 
---------------------
===================
Zane Kukta (Zefk)
===================

----------------------------
Solarus ARPG Engine Creator:
----------------------------
============================
Christopho
============================

-------------
About Script:
-------------
========================================================================================
This script is a title screen menu. The place where the player starts the game or exits.
========================================================================================

---------
Features:
---------
================================================================================================================
1.Start game
2.Exit game
3.Change action key
4.Change action key sound
5.Change menu music
6.Change up and down key sound
================================================================================================================

--------------------
Install Instructions
--------------------
========================================================================================
1. Put the title screen.lua script in the directory "scripts/"
2. Go to main.lua and add the following under the Solarus logo on_finished function.

--------
Example:
--------
  -- Start the game when the Solarus logo menu is finished.
  solarus_logo.on_finished = function()
    -- Show the title screen after the Solarus Logo
    local title_screen_menu = require("scripts/title_screen")
    sol.menu.start(self, title_screen_menu)

    title_screen_menu.on_finished = function()
     game_manager:start_game()
    end
  end

3. Put the folder "title_screen" that contains images for the menu in the directory "sprites/"

========================================================================================


-------------------
Usage Instructions:
-------------------
========================================================================================
1.Use the up and down keys
2.Change the action key to what you desire in the change area. By default it is key "a".
========================================================================================

-----------------------
Script Completion Date:
-----------------------
==============================
4-1-17 [April 1st, 2017]
==============================

--------
License: 
--------
=============================================================================================================================================
Free under GPLv3 by default. It uses Solarus functions and Solarus is under GPLv3. Credit the (2) people involved in script and link to their websites.

---------
Websites:
---------
Zane Kukta (Zefk) <http://zelzec-entertainment.weebly.com/>
Christopho <http://www.solarus-games.org/>
================================================================================================================
--]]

--Make a menu
local title_screen_menu = {}

--Table for variables related to this script.
local title_screen ={

--Browse is the default starting point. 
--0 = start 
--1 = exit
   browse = 0,

--Start up and down at zero to use them with basic math
   up = 0,
   down = 0,

--Creating/loading images
   bg_img = sol.surface.create("title_screen/background.png"),
   idle_text_img = sol.surface.create("title_screen/idle_start_exit.png"),
   logo_img = sol.surface.create("title_screen/logo.png"),
   rules_img = sol.surface.create("title_screen/rules.png"),
   start_hover_img = sol.surface.create("title_screen/start_hover.png"),
   exit_hover_img = sol.surface.create("title_screen/exit_hover.png"),

--Shows the background image
   bg = true,

--Shows the start/exit idle image
   idle = true,

--Shows the modified Solarus logo image
   logo = true,

--Shows The Solarus Rules 2017 image
   rules = true,

--Sets hover images to false at start.
   start_hover = false,
   exit_hover = false,

--Allow to use the up and down keys
   up = true,
   down = true,

--Check the change area below and change settings there.
--The Action key. The button the is pressed to proceed somewhere else.
   action_key = "none",

--The sound the action key makes
   action_key_sound = "none",

--The up and down keys sound
   up_down_sound = "none",

}

--==============================================================================================================
--CHANGE AREA:
--==============================================================================================================

--Change music
sol.audio.play_music("diarandor/select_name_menu")

--Change action key
title_screen.action_key = "a"

--Change sound when action key is pressed
title_screen.action_key_sound = "pause_closed"

--Change up and down keys sound
title_screen.up_down_sound = "cursor"

--==============================================================================================================

--Hover image start activates on 0 by default
if title_screen.browse == 0 then
  title_screen.start_hover = true 
  title_screen.exit_hover = false
end

--Hover image exit activates on 1 by default
if title_screen.browse == 1 then
  title_screen.start_hover = false 
  title_screen.exit_hover = true
end

--The draw function for showing images
function title_screen_menu:on_draw(screen)

--Show background when conditions are true
   if title_screen.bg == true then
     title_screen.bg_img:draw(screen)
   end

--Show logo when conditions are true
   if title_screen.logo == true then
     title_screen.logo_img:draw(screen)
   end

--Show idle text when conditions are true
   if title_screen.idle == true then
     title_screen.idle_text_img:draw(screen)
   end

--Show rules text when conditions are true
   if title_screen.rules == true then
     title_screen.rules_img:draw(screen)
   end

--Show start hover text when conditions are true
   if title_screen.start_hover == true then
     title_screen.start_hover_img:draw(screen)
   end

--Show exit hover text when conditions are true
   if title_screen.exit_hover == true then
     title_screen.exit_hover_img:draw(screen)
   end

end -- End of draw function

--key function for pressing buttons
function title_screen_menu:on_key_pressed(key)

--Go down
  if key == "down" and title_screen.up == true then
    sol.audio.play_sound(title_screen.up_down_sound)
    if title_screen.browse < 1 then
      title_screen.browse = title_screen.browse + 1
    end
  end

--Go up
  if key == "up" and title_screen.down == true then
    sol.audio.play_sound(title_screen.up_down_sound)
    if title_screen.browse > 0 then
      title_screen.browse = title_screen.browse - 1
    end
  end

  --Hover image start activates on 0
  if title_screen.browse == 0 then
    title_screen.start_hover = true 
    title_screen.exit_hover = false
  
  --Activate action key, action key sound, and stop menu.
    if key == title_screen.action_key then
     sol.audio.play_sound(title_screen.action_key_sound)
     sol.menu.stop(title_screen_menu)
    end
  end
  
  --Hover image exit activates on 1
  if title_screen.browse == 1 then
    title_screen.start_hover = false 
    title_screen.exit_hover = true
  
  --Activate action key and exit game
    if key == title_screen.action_key then
     sol.main.exit()
    end
  end
end -- end of key pressed function

return title_screen_menu --Return menu


