-- Lua script of map Map_4.
-- This script is executed every time the hero enters this map.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation:
-- http://www.solarus-games.org/doc/latest

local map = ...
local game = map:get_game()
local hero = map:get_hero()
local camera = map:get_camera()

--Create on_activated
sol.timer.start(500, function()
  if map.on_activated ~= nil then
    map:on_activated()
 return true 
  end
end)


function map:on_activated()

--Force sprites to turn toward each other
  npc_2:get_sprite():set_direction(npc_2:get_direction4_to(npc))
  npc:get_sprite():set_direction(npc:get_direction4_to(npc_2))
  
  
--Print "spin attack" when the spin attack is used.
  function hero:on_state_changed(state)
  
    if state == "sword spin attack" then
      print("spin attack")
    end
  end


 --Get distance to entity
  print("------------",hero:get_distance(sprite))
  
  local distance_between = hero:get_distance(sprite)

  if distance_between < 20 then
  
    print("BAM! You are the boss!")
  end

end --end of on_activated

function door_trigger:on_activated()
  map:open_doors("switch_door")
  sol.audio.play_sound("door_open")
end

game:set_ability("sword_knowledge", 0)


