local map = ...
local game = map:get_game()
function map:on_key_pressed(key)

  if key == "l" then
   --game:set_suspended(true)
  end

  if key == "q" then
   game:set_suspended(false)
   sol.audio.play_music(map:get_music())
  end

end