--[[
--------------
Instructions:
--------------
============================================================================================================
Key "m" is for moving the cursor image around on the screen. You can turn off the cursor and use it instead.
Key "c" makes it so one can click the cursor around (Press "m" first because "c" will stop the timer)
Key "t" displays the timer
Key "a" sets the timer to 20 seconds and stops the cursor image.
============================================================================================================
--]]

--Pass the game parameter to the script.
local game = ...

--Creating surfaces for the images and loading in the images.
local arrow_img = sol.surface.create ("arrow.png")

--Makes the timer display, clicking the mouse around, and moving the mouse not being at start of script.
local click_mouse_xy = false
local move_mouse_xy = false
local time_display = false

--Variables for the timer display
local milliseconds = 0
local seconds = 0 
local minutes = 0
local hours   = 0


--MOVES IMAGE AROUND SCREEN BY CLICKING VARIABLES
--A table because I like tables and it prevents upvalue errors
local click = {
 
     place_x,
     place_y,
}

--DRAG IMAGE AROUND THE SCREEN VARIABLES
--A table because I like tables and it prevents upvalue errors
local move = {

     place_x,
     place_y,
}

--Function for mouse releases
function sol.main:on_mouse_released(button, x, y)

--MOVES IMAGE AROUND SCREEN BY CLICKING.
   if click_mouse_xy == true then
     if button == "left" then
       --Setting x,y drag to get mouse position.
       local drag_x,drag_y = sol.input.get_mouse_position()
       click.place_x = drag_x
       click.place_y = drag_y
       print("x,",click.place_x, "y",click.place_y)
     end
   end
end

     --DRAG IMAGE AROUND THE SCREEN
     local num_calls = 0
     --Assign variable "test" to the timer
     local test = sol.timer.start(80, function()
       --Setting x,y drag to get mouse position.
         local drag_x,drag_y = sol.input.get_mouse_position()
         move.place_x = drag_x
         move.place_y = drag_y
         print("x,",move.place_x, "y",move.place_y)
         return num_calls ~= 1
     end)

--Solarus key pressing function
function sol.main:on_key_pressed(key)
   --Pause the game
   game:set_paused(true)

   if key == "c" then
     click_mouse_xy = true
     move_mouse_xy = false
     --Stop the timer "test"
     test:stop()
     --Timer "test" sound is off
     test:set_with_sound(false)
   end

   if key == "m" then
     click_mouse_xy = false
     move_mouse_xy = true
     --Timer "test" sound is on
     --The timer will be very fast and annoying at 80 milliseconds. It will go slower with like 5000 (5 seconds)
     test:set_with_sound(true)
   end

   if key == "t" then
     --Turn on the timer display
     time_display = true
   end

   if key == "a" then 
     --Change the time to 20 seconds
     test:set_remaining_time(20000)
   end
end -- end of key press function
 
--The draw function for showing images
function sol.main:on_draw(screen)

--Basic time calculations. There is no int (integer) declaration for variables in Lua, so I used math.floor.
--Math.floor rounds down and math.ceil rounds up math.floor(0.5) = 0 and math.ceil(0.5) = 1
seconds = math.floor((milliseconds / 1000) % 60) 
minutes = math.floor(((milliseconds / (1000*60)) % 60))
hours   = math.floor(((milliseconds / (1000*60*60)) % 24))

--TEXT ON SCREEN
--http://www.solarus-games.org/doc/latest/lua_api_text_surface.html
    local text_display = sol.text_surface.create({ -- name a local variable something and assign it to the sol.text_surface
      font = "minecraftia", -- font name
      text = hours..":"..minutes..":"..seconds..":"..milliseconds, -- text you want to show
      rendering_mode = "solid", -- "solid" (faster) and default
      color = {0,0,0}, -- color must be in a table RGB (http://www.rapidtables.com/web/color/RGB_Color.htm)
    })

if move_mouse_xy == true then
  --Get the remaining time of the timer "test." This is displayed at the end, "text = hours..":"..minutes..":"..seconds..":"..milliseconds."
  milliseconds = test:get_remaining_time()
  print(test:get_remaining_time())
end

   if click_mouse_xy == true then
     arrow_img:draw(screen, click.place_x,click.place_y)
   end

   if move_mouse_xy == true then
     arrow_img:draw(screen, move.place_x,move.place_y)
   end

   if time_display == true then
     text_display:draw(screen, 20,20)
   end

end --end of draw function


