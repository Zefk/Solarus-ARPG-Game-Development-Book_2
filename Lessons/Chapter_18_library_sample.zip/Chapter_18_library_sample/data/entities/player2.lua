-- Lua script of custom entity player2.
-- This script is executed every time a custom entity with this model is created.

-- Feel free to modify the code below.
-- You can add more events and remove the ones you don't need.

-- See the Solarus Lua API documentation for the full specification
-- of types, events and methods:
-- http://www.solarus-games.org/doc/latest

local entity = ...
local game = entity:get_game()
local map = entity:get_map()
local hero = map:get_hero()
local sprite
menu = false
 
local camera = map:get_camera()
camera:start_tracking(entity)
 
---Create sprite
function entity:on_created()
  sprite = entity:create_sprite("hero/tunic1"):set_animation("stopped")
  entity:set_can_traverse("hero", false)
  entity:speed(80)
end
 
--Key press function
function sol.main:on_key_pressed(key)
 
--right
  if key == "l" and menu == false then
    entity:right()
  end
 
--up
  if key == "i" and menu == false then
    entity:up()
  end
 
--left
  if key == "j" and menu == false then
    entity:left()
  end
 
--down
  if key == "k" and menu == false then
    entity:down()
  end
end
 
function sol.main:on_key_released(key)
   --right
   if key == "l" then
       entity:stop()
   end
 
   --up
   if key == "i" then
       entity:stop()
   end
 
   --left
   if key == "j" then
       entity:stop()
   end
 
   --down
   if key == "k" then
       entity:stop()
   end
end
