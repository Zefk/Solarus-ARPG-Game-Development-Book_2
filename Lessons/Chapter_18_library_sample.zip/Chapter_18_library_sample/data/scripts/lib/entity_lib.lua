--This is a library for custom entity shortcuts

local metatable_entity = sol.main.get_metatable("custom_entity")

------------------
--Straight Method
------------------
local move_straight = sol.movement.create("straight")

--Right



function metatable_entity:right()

local map = self:get_map()
local player2 = map:get_entity("player2")

  move_straight:set_angle(0)
  move_straight:start(player2)
  player2:set_direction(0)
  player2:get_sprite():set_animation("walking")
end

--Up
function metatable_entity:up()
  move_straight:set_angle(math.pi / 2)
  move_straight:start(self)
  self:set_direction(1)
  self:get_sprite():set_animation("walking")
end

--Left
function metatable_entity:left()
  move_straight:set_angle(math.pi)
  move_straight:start(self)
  self:set_direction(2)
  self:get_sprite():set_animation("walking")
end
 
--Down
function metatable_entity:down()
  move_straight:set_angle(3 * math.pi / 2)
  move_straight:start(self)
  self:set_direction(3)
  self:get_sprite():set_animation("walking")
end

--Stop
function metatable_entity:stop()
  move_straight:stop()
  self:get_sprite():set_animation("stopped")
end

--Speed
function metatable_entity:speed(value)
  move_straight:set_speed(value)
end

 

 

