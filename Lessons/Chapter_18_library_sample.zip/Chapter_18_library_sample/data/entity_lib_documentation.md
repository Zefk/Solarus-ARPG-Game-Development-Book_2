#Zefk's Entity Lib

###Lib installation

In `main.lua` put the following line of code at the top of the script.

```lua
require("scripts/lib/zefk_entity_lib.lua")
```

Put the folder `lib` in the `scripts/` directory.


###Entity Straight Method

The entity straight method allows one to move an entity continuously in one direction.
```
entity:[direction]()
```
|Possible directions|
|------------------|
|up|
|down|
|left|
|right|

**Example Usages:**
```lua
entity:up()
entity:down()
entity:left()
entity:right()
```

###Entity Stop Method
The movement can be stopped by calling:

```lua
entity:stop()
```

**Reserved word:**
- move_straight

###Entity Speed Method

`entity:speed(value)`

**Example Usage:**

```lua
  entity:speed(80)
  ```